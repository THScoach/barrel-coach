-- ============================================================================
-- KWON-STYLE ANALYSIS TABLES
-- "We don't add, we unlock. Measure to understand, not enforce."
-- ============================================================================

-- Kwon analyses table - stores complete analysis results
CREATE TABLE IF NOT EXISTS kwon_analyses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID NOT NULL REFERENCES sensor_sessions(id) ON DELETE CASCADE,
  player_id UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,

  -- Analysis timestamp
  analysis_date TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  -- Data quality
  swings_analyzed INTEGER NOT NULL,
  data_quality TEXT NOT NULL CHECK (data_quality IN ('excellent', 'good', 'limited')),

  -- Motor profile classification
  motor_profile TEXT NOT NULL CHECK (motor_profile IN ('Spinner', 'Slingshotter', 'Whipper', 'Titan', 'Unknown')),

  -- Sensor facts (MEASURED - 100% confidence)
  sensor_facts JSONB NOT NULL,
  -- Schema: {
  --   swingCount, batSpeedMax, batSpeedMean, batSpeedStdDev,
  --   handSpeedMax, handSpeedMean, handSpeedStdDev,
  --   timeToContactMean, timeToContactStdDev, timingCV,
  --   attackAngleMean, attackAngleStdDev,
  --   attackDirectionMean, attackDirectionStdDev,
  --   handToBatRatio, rotationalAccelerationMean?, onPlaneEfficiencyMean?, connectionAngleMean?
  -- }

  -- Release prediction (HIGH confidence)
  release_prediction JSONB NOT NULL,
  -- Schema: {
  --   handToBatRatio, quality, percentile, potentialUnlock, confidence, reasoning
  -- }

  -- Timing prediction (MEDIUM confidence)
  timing_prediction JSONB NOT NULL,
  -- Schema: {
  --   consistencyScore, tempoCategory, adjustability, predictedTimingWindow,
  --   potentialUnlock, confidence, reasoning
  -- }

  -- Upstream prediction (LOW confidence)
  upstream_prediction JSONB NOT NULL,
  -- Schema: {
  --   estimatedHipContribution, estimatedTorsoContribution, likelyKineticChainBreaks,
  --   potentialUnlock, confidence, reasoning, needsVideoFor
  -- }

  -- Kinetic potential
  kinetic_potential JSONB NOT NULL,
  -- Schema: {
  --   currentBatSpeed, projectedPotential, totalUnlock,
  --   releaseUnlock, timingUnlock, upstreamUnlock,
  --   overallConfidence, validationNeeds
  -- }

  -- Possible leaks
  possible_leaks JSONB NOT NULL DEFAULT '[]',
  -- Schema: Array of {
  --   leakType, category, description, probability, evidence, potentialGain, howToConfirm
  -- }

  -- 4B scores from sensor
  four_b_scores JSONB NOT NULL,
  -- Schema: {
  --   bat: { overall, batSpeedScore, handSpeedScore, releaseScore, accelerationScore?, confidence },
  --   brain: { overall, timingConsistency, pathConsistency, zoneAdaptability, confidence, reasoning },
  --   body: { overall, estimatedSequencing, estimatedSeparation, estimatedGroundForce, confidence, reasoning, needsVideoFor },
  --   ball: { overall, available, exitVelocity?, launchAngle?, hardHitRate?, confidence },
  --   compositeScore, confidenceNote
  -- }

  -- Focus areas
  priority_focus TEXT NOT NULL,
  secondary_focus TEXT NOT NULL,

  -- Metadata
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes for efficient querying
CREATE INDEX idx_kwon_analyses_player_id ON kwon_analyses(player_id);
CREATE INDEX idx_kwon_analyses_session_id ON kwon_analyses(session_id);
CREATE INDEX idx_kwon_analyses_analysis_date ON kwon_analyses(analysis_date DESC);
CREATE INDEX idx_kwon_analyses_motor_profile ON kwon_analyses(motor_profile);

-- Kinetic fingerprints table - aggregated patterns over time
CREATE TABLE IF NOT EXISTS kinetic_fingerprints (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  player_id UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,

  -- Fingerprint data
  intent_map JSONB NOT NULL,
  -- Schema: {
  --   horizontalMean, horizontalStdDev, verticalMean, verticalStdDev,
  --   depthIndex, depthConsistency
  -- }

  timing_signature JSONB NOT NULL,
  -- Schema: {
  --   triggerToImpactMs, timingVariance, tempoCategory
  -- }

  pattern_metrics JSONB NOT NULL,
  -- Schema: {
  --   tightness, pullBias, zoneBias, comfortZone: { horizontal, vertical }
  -- }

  body_sequence JSONB,
  -- Schema (optional - requires video): {
  --   kineticChainOrder, separationAngle, energyTransferEfficiency
  -- }

  -- Computed metrics
  swing_count INTEGER NOT NULL DEFAULT 0,
  motor_profile TEXT CHECK (motor_profile IN ('Spinner', 'Slingshotter', 'Whipper', 'Titan', 'Unknown')),

  -- Timestamps
  last_updated TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Unique constraint on player_id (one fingerprint per player)
CREATE UNIQUE INDEX idx_kinetic_fingerprints_player_unique ON kinetic_fingerprints(player_id);

-- Fingerprint history for tracking progression
CREATE TABLE IF NOT EXISTS kinetic_fingerprint_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  player_id UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  fingerprint_snapshot JSONB NOT NULL,
  swing_count INTEGER NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_fingerprint_history_player ON kinetic_fingerprint_history(player_id, recorded_at DESC);

-- ============================================================================
-- ANALYSIS COMPARISON TRACKING
-- ============================================================================

CREATE TABLE IF NOT EXISTS analysis_comparisons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  player_id UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  older_analysis_id UUID NOT NULL REFERENCES kwon_analyses(id) ON DELETE CASCADE,
  newer_analysis_id UUID NOT NULL REFERENCES kwon_analyses(id) ON DELETE CASCADE,

  -- Comparison metrics
  bat_speed_change DECIMAL(5,2) NOT NULL,
  hand_to_bat_ratio_change DECIMAL(5,4) NOT NULL,
  consistency_change DECIMAL(5,2) NOT NULL,
  potential_change DECIMAL(5,2) NOT NULL,

  -- Summary
  improved BOOLEAN NOT NULL,
  summary TEXT NOT NULL,

  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_analysis_comparisons_player ON analysis_comparisons(player_id, created_at DESC);

-- ============================================================================
-- FUNCTIONS
-- ============================================================================

-- Function to update fingerprint from new analysis
CREATE OR REPLACE FUNCTION update_fingerprint_from_analysis()
RETURNS TRIGGER AS $$
DECLARE
  v_current_count INTEGER;
  v_new_swing_count INTEGER;
  v_weight DECIMAL;
BEGIN
  -- Get current fingerprint
  SELECT swing_count INTO v_current_count
  FROM kinetic_fingerprints
  WHERE player_id = NEW.player_id;

  v_new_swing_count := NEW.swings_analyzed;

  IF v_current_count IS NULL THEN
    -- Create new fingerprint from first analysis
    INSERT INTO kinetic_fingerprints (
      player_id, intent_map, timing_signature, pattern_metrics,
      swing_count, motor_profile, last_updated
    )
    SELECT
      NEW.player_id,
      jsonb_build_object(
        'horizontalMean', (NEW.sensor_facts->>'attackDirectionMean')::DECIMAL,
        'horizontalStdDev', (NEW.sensor_facts->>'attackDirectionStdDev')::DECIMAL,
        'verticalMean', (NEW.sensor_facts->>'attackAngleMean')::DECIMAL,
        'verticalStdDev', (NEW.sensor_facts->>'attackAngleStdDev')::DECIMAL,
        'depthIndex', (NEW.kinetic_potential->'timingUnlock'->>'value')::DECIMAL,
        'depthConsistency', 100 - ((NEW.sensor_facts->>'timingCV')::DECIMAL * 100)
      ),
      jsonb_build_object(
        'triggerToImpactMs', (NEW.sensor_facts->>'timeToContactMean')::DECIMAL,
        'timingVariance', (NEW.sensor_facts->>'timingCV')::DECIMAL,
        'tempoCategory', NEW.timing_prediction->>'tempoCategory'
      ),
      jsonb_build_object(
        'tightness', 100 - ((NEW.sensor_facts->>'attackAngleStdDev')::DECIMAL +
                           (NEW.sensor_facts->>'attackDirectionStdDev')::DECIMAL) * 2,
        'pullBias', (NEW.sensor_facts->>'attackDirectionMean')::DECIMAL,
        'zoneBias', CASE
          WHEN (NEW.sensor_facts->>'attackAngleMean')::DECIMAL < -5 THEN 'low'
          WHEN (NEW.sensor_facts->>'attackAngleMean')::DECIMAL > 15 THEN 'high'
          ELSE 'middle'
        END,
        'comfortZone', jsonb_build_object(
          'horizontal', jsonb_build_array(-10, 10),
          'vertical', jsonb_build_array(5, 25)
        )
      ),
      v_new_swing_count,
      NEW.motor_profile,
      NOW();
  ELSE
    -- Update existing fingerprint with weighted average
    v_weight := v_new_swing_count::DECIMAL / (v_current_count + v_new_swing_count);

    UPDATE kinetic_fingerprints
    SET
      swing_count = v_current_count + v_new_swing_count,
      motor_profile = NEW.motor_profile,
      last_updated = NOW(),
      -- Update timing signature
      timing_signature = jsonb_build_object(
        'triggerToImpactMs', (timing_signature->>'triggerToImpactMs')::DECIMAL * (1 - v_weight) +
                             (NEW.sensor_facts->>'timeToContactMean')::DECIMAL * v_weight,
        'timingVariance', (timing_signature->>'timingVariance')::DECIMAL * (1 - v_weight) +
                          (NEW.sensor_facts->>'timingCV')::DECIMAL * v_weight,
        'tempoCategory', NEW.timing_prediction->>'tempoCategory'
      )
    WHERE player_id = NEW.player_id;
  END IF;

  -- Record snapshot for history
  INSERT INTO kinetic_fingerprint_history (player_id, fingerprint_snapshot, swing_count)
  SELECT player_id,
         jsonb_build_object(
           'intentMap', intent_map,
           'timingSignature', timing_signature,
           'patternMetrics', pattern_metrics,
           'motorProfile', motor_profile
         ),
         swing_count
  FROM kinetic_fingerprints
  WHERE player_id = NEW.player_id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update fingerprint on new analysis
DROP TRIGGER IF EXISTS trg_update_fingerprint ON kwon_analyses;
CREATE TRIGGER trg_update_fingerprint
  AFTER INSERT ON kwon_analyses
  FOR EACH ROW
  EXECUTE FUNCTION update_fingerprint_from_analysis();

-- ============================================================================
-- UPDATED_AT TRIGGERS
-- ============================================================================

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_kwon_analyses_updated_at ON kwon_analyses;
CREATE TRIGGER trg_kwon_analyses_updated_at
  BEFORE UPDATE ON kwon_analyses
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================

ALTER TABLE kwon_analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE kinetic_fingerprints ENABLE ROW LEVEL SECURITY;
ALTER TABLE kinetic_fingerprint_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE analysis_comparisons ENABLE ROW LEVEL SECURITY;

-- Players can view their own analyses
CREATE POLICY kwon_analyses_player_select ON kwon_analyses
  FOR SELECT USING (
    player_id IN (
      SELECT id FROM players WHERE user_id = auth.uid()
    )
  );

-- Coaches can view analyses for their players
CREATE POLICY kwon_analyses_coach_select ON kwon_analyses
  FOR SELECT USING (
    player_id IN (
      SELECT id FROM players WHERE coach_id = auth.uid()
    )
  );

-- Similar policies for fingerprints
CREATE POLICY fingerprints_player_select ON kinetic_fingerprints
  FOR SELECT USING (
    player_id IN (
      SELECT id FROM players WHERE user_id = auth.uid()
    )
  );

CREATE POLICY fingerprints_coach_select ON kinetic_fingerprints
  FOR SELECT USING (
    player_id IN (
      SELECT id FROM players WHERE coach_id = auth.uid()
    )
  );

-- ============================================================================
-- COMMENTS
-- ============================================================================

COMMENT ON TABLE kwon_analyses IS 'Kwon-style sensor analysis results with confidence levels';
COMMENT ON TABLE kinetic_fingerprints IS 'Aggregated kinetic fingerprint patterns per player';
COMMENT ON TABLE kinetic_fingerprint_history IS 'Historical snapshots of fingerprint progression';
COMMENT ON TABLE analysis_comparisons IS 'Tracked comparisons between analyses showing progress';
