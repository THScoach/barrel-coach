-- ============================================================================
-- CATCHING BARRELS - GAMIFICATION & COMMUNITY TABLES
-- Migration for sensor-first platform build
-- January 2026
-- ============================================================================

-- ============================================
-- PLAYERS TABLE (Member profiles)
-- ============================================
CREATE TABLE IF NOT EXISTS players (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,

  -- Basic Info
  name VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  age INTEGER CHECK (age >= 5 AND age <= 50),
  age_group VARCHAR(20) CHECK (age_group IN ('10U', '11U', '12U', '13U', '14U', '15U', '16U', '17U', '18U', 'College', 'Pro', 'Adult')),

  -- Motor Profile (from Kinetic Fingerprint analysis)
  motor_profile VARCHAR(30) CHECK (motor_profile IN ('Spinner', 'Slingshotter', 'Whipper', 'Titan', 'Unknown')),

  -- Membership
  membership_tier VARCHAR(20) NOT NULL DEFAULT 'Free' CHECK (membership_tier IN ('Free', 'Community', 'Full')),
  membership_status VARCHAR(20) NOT NULL DEFAULT 'Active' CHECK (membership_status IN ('Trial', 'Active', 'Paused', 'Cancelled', 'Payment Issue')),

  -- Sensor Info
  sensor_serial VARCHAR(50),
  sensor_shipped_date DATE,
  sensor_delivered_date DATE,
  baseline_complete BOOLEAN DEFAULT FALSE,

  -- Gamification
  current_streak INTEGER DEFAULT 0,
  longest_streak INTEGER DEFAULT 0,
  total_xp INTEGER DEFAULT 0,
  level INTEGER DEFAULT 1,

  -- Kinetic Fingerprint
  kinetic_fingerprint_url TEXT,
  kinetic_fingerprint_json JSONB,

  -- External IDs
  whop_member_id VARCHAR(100),
  ghl_contact_id VARCHAR(100),
  stripe_customer_id VARCHAR(100),

  -- Parent Info (for youth players)
  parent_name VARCHAR(100),
  parent_email VARCHAR(255),
  parent_phone VARCHAR(20),

  -- Activity Tracking
  last_session_date DATE,
  sessions_this_week INTEGER DEFAULT 0,

  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- SENSOR SESSIONS TABLE
-- Each practice/training session with sensor
-- ============================================
CREATE TABLE IF NOT EXISTS sensor_sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  player_id UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,

  -- DK Integration
  dk_session_uuid VARCHAR(100) UNIQUE,

  -- Session Stats
  total_swings INTEGER DEFAULT 0,
  bat_speed_max DECIMAL(5,2),
  bat_speed_avg DECIMAL(5,2),
  hand_speed_max DECIMAL(5,2),

  -- Kinetic Fingerprint Data
  kinetic_fingerprint_json JSONB,
  attack_angle_avg DECIMAL(5,2),
  attack_direction_avg DECIMAL(5,2),
  timing_variance DECIMAL(5,4),

  -- 4B Scores (BAT + BRAIN from sensor)
  four_b_bat DECIMAL(5,2),
  four_b_brain DECIMAL(5,2),

  -- Session Metadata
  session_date DATE NOT NULL DEFAULT CURRENT_DATE,
  duration_minutes INTEGER,
  environment VARCHAR(20) CHECK (environment IN ('tee', 'soft_toss', 'front_toss', 'bp', 'machine', 'live', 'unknown')),

  -- Video (if captured)
  video_url TEXT,
  video_storage_path TEXT,

  -- Status
  status VARCHAR(20) DEFAULT 'syncing' CHECK (status IN ('syncing', 'complete', 'failed')),

  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  synced_at TIMESTAMP WITH TIME ZONE
);

-- ============================================
-- SENSOR SWINGS TABLE
-- Individual swings within a session
-- ============================================
CREATE TABLE IF NOT EXISTS sensor_swings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sensor_session_id UUID NOT NULL REFERENCES sensor_sessions(id) ON DELETE CASCADE,
  player_id UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,

  -- DK Integration
  dk_swing_uuid VARCHAR(100) UNIQUE,
  swing_index INTEGER NOT NULL,

  -- DK Metrics
  bat_speed_mph DECIMAL(5,2),
  hand_speed_mph DECIMAL(5,2),
  attack_angle_deg DECIMAL(5,2),
  attack_direction_deg DECIMAL(5,2),
  swing_plane_tilt_deg DECIMAL(5,2),
  time_to_contact_ms INTEGER,
  speed_efficiency DECIMAL(5,4),
  power_applied DECIMAL(10,2),

  -- Impact Location
  impact_loc_x DECIMAL(5,3),
  impact_loc_y DECIMAL(5,3),
  impact_loc_z DECIMAL(5,3),

  -- Computed/Estimated
  exit_velo_estimated DECIMAL(5,2),

  -- Timestamps
  swing_timestamp TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

  UNIQUE(sensor_session_id, swing_index)
);

-- ============================================
-- XP LOG TABLE
-- Track all XP awards
-- ============================================
CREATE TABLE IF NOT EXISTS xp_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  player_id UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,

  amount INTEGER NOT NULL,
  reason VARCHAR(100) NOT NULL,
  -- Reasons: session_complete, pr_hit, weekly_challenge_win, streak_7, streak_30, streak_100, level_up_bonus, fingerprint_tightened

  new_total INTEGER NOT NULL,

  -- Optional reference to what triggered this XP
  reference_type VARCHAR(50),
  reference_id UUID,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- WEEKLY CHALLENGES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS weekly_challenges (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

  week_start DATE NOT NULL,
  week_end DATE NOT NULL,

  challenge_type VARCHAR(50) NOT NULL,
  -- Types: contact_week, tempo_week, power_week, consistency_week, efficiency_week

  name VARCHAR(100) NOT NULL,
  description TEXT,

  target_metric VARCHAR(50),
  target_value DECIMAL(10,4),
  target_type VARCHAR(20) DEFAULT 'above', -- above, below, highest, lowest
  min_swings INTEGER DEFAULT 20,

  -- Winner
  winner_player_id UUID REFERENCES players(id),
  winner_value DECIMAL(10,4),

  -- Status
  status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'complete', 'cancelled')),

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- CHALLENGE ENTRIES TABLE
-- Player participation in challenges
-- ============================================
CREATE TABLE IF NOT EXISTS challenge_entries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  challenge_id UUID NOT NULL REFERENCES weekly_challenges(id) ON DELETE CASCADE,
  player_id UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,

  current_value DECIMAL(10,4),
  swings_count INTEGER DEFAULT 0,

  is_winner BOOLEAN DEFAULT FALSE,

  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

  UNIQUE(challenge_id, player_id)
);

-- ============================================
-- COMMUNITY POSTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS community_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  player_id UUID REFERENCES players(id) ON DELETE SET NULL,

  post_type VARCHAR(30) NOT NULL CHECK (post_type IN ('announcement', 'win', 'pr', 'discussion', 'swing_review', 'welcome', 'streak_milestone', 'level_up', 'challenge_win')),

  content TEXT,
  media_url TEXT,
  media_type VARCHAR(20), -- image, video

  -- For auto-generated posts
  auto_generated BOOLEAN DEFAULT FALSE,
  event_type VARCHAR(50),
  event_data JSONB,

  -- Moderation
  is_pinned BOOLEAN DEFAULT FALSE,
  is_featured BOOLEAN DEFAULT FALSE,
  is_hidden BOOLEAN DEFAULT FALSE,

  -- Engagement counts (denormalized for performance)
  reaction_count INTEGER DEFAULT 0,
  comment_count INTEGER DEFAULT 0,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- COMMUNITY COMMENTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS community_comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  post_id UUID NOT NULL REFERENCES community_posts(id) ON DELETE CASCADE,
  player_id UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,

  content TEXT NOT NULL,

  -- Reply threading
  parent_comment_id UUID REFERENCES community_comments(id) ON DELETE CASCADE,

  is_hidden BOOLEAN DEFAULT FALSE,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- COMMUNITY REACTIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS community_reactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  post_id UUID NOT NULL REFERENCES community_posts(id) ON DELETE CASCADE,
  player_id UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,

  reaction_type VARCHAR(20) NOT NULL CHECK (reaction_type IN ('fire', 'muscle', 'clap', 'heart', 'hundred')),

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

  UNIQUE(post_id, player_id)
);

-- ============================================
-- LEADERBOARD SNAPSHOTS TABLE
-- Weekly snapshots for historical tracking
-- ============================================
CREATE TABLE IF NOT EXISTS leaderboard_snapshots (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

  leaderboard_type VARCHAR(50) NOT NULL, -- weekly_swings, consistency, bat_speed, challenges_won
  week_start DATE NOT NULL,

  rankings JSONB NOT NULL, -- Array of {player_id, rank, value, name}

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

  UNIQUE(leaderboard_type, week_start)
);

-- ============================================
-- MONDAY CALL RECORDINGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS monday_calls (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

  call_date DATE NOT NULL,
  title VARCHAR(200),
  description TEXT,

  -- Recording
  recording_url TEXT,
  duration_minutes INTEGER,

  -- Featured swings
  featured_swing_ids UUID[],

  -- Topics covered (for search)
  topics TEXT[],

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================
-- MONDAY CALL ATTENDANCE TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS monday_call_attendance (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  call_id UUID NOT NULL REFERENCES monday_calls(id) ON DELETE CASCADE,
  player_id UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,

  joined_at TIMESTAMP WITH TIME ZONE,
  left_at TIMESTAMP WITH TIME ZONE,

  UNIQUE(call_id, player_id)
);

-- ============================================
-- INDEXES
-- ============================================
CREATE INDEX idx_players_email ON players(email);
CREATE INDEX idx_players_membership ON players(membership_tier, membership_status);
CREATE INDEX idx_players_streak ON players(current_streak DESC);
CREATE INDEX idx_players_xp ON players(total_xp DESC);
CREATE INDEX idx_players_ghl ON players(ghl_contact_id);
CREATE INDEX idx_players_whop ON players(whop_member_id);

CREATE INDEX idx_sensor_sessions_player ON sensor_sessions(player_id);
CREATE INDEX idx_sensor_sessions_date ON sensor_sessions(session_date DESC);
CREATE INDEX idx_sensor_swings_session ON sensor_swings(sensor_session_id);
CREATE INDEX idx_sensor_swings_player ON sensor_swings(player_id);

CREATE INDEX idx_xp_log_player ON xp_log(player_id);
CREATE INDEX idx_xp_log_created ON xp_log(created_at DESC);

CREATE INDEX idx_challenges_week ON weekly_challenges(week_start);
CREATE INDEX idx_challenge_entries_player ON challenge_entries(player_id);

CREATE INDEX idx_community_posts_type ON community_posts(post_type);
CREATE INDEX idx_community_posts_created ON community_posts(created_at DESC);
CREATE INDEX idx_community_posts_player ON community_posts(player_id);
CREATE INDEX idx_community_comments_post ON community_comments(post_id);
CREATE INDEX idx_community_reactions_post ON community_reactions(post_id);

-- ============================================
-- ROW LEVEL SECURITY
-- ============================================
ALTER TABLE players ENABLE ROW LEVEL SECURITY;
ALTER TABLE sensor_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE sensor_swings ENABLE ROW LEVEL SECURITY;
ALTER TABLE xp_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE weekly_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE challenge_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_reactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE monday_calls ENABLE ROW LEVEL SECURITY;
ALTER TABLE monday_call_attendance ENABLE ROW LEVEL SECURITY;

-- Players: Users can read all, update own
CREATE POLICY "Players viewable by all" ON players FOR SELECT USING (true);
CREATE POLICY "Players updatable by owner" ON players FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Players insertable by service" ON players FOR INSERT WITH CHECK (true);

-- Sensor data: Viewable by all, writable by owner/service
CREATE POLICY "Sensor sessions viewable" ON sensor_sessions FOR SELECT USING (true);
CREATE POLICY "Sensor sessions insertable" ON sensor_sessions FOR INSERT WITH CHECK (true);
CREATE POLICY "Sensor swings viewable" ON sensor_swings FOR SELECT USING (true);
CREATE POLICY "Sensor swings insertable" ON sensor_swings FOR INSERT WITH CHECK (true);

-- XP log: Viewable by owner
CREATE POLICY "XP log viewable by owner" ON xp_log FOR SELECT
  USING (player_id IN (SELECT id FROM players WHERE user_id = auth.uid()));
CREATE POLICY "XP log insertable by service" ON xp_log FOR INSERT WITH CHECK (true);

-- Challenges: Viewable by all
CREATE POLICY "Challenges viewable" ON weekly_challenges FOR SELECT USING (true);
CREATE POLICY "Challenge entries viewable" ON challenge_entries FOR SELECT USING (true);

-- Community: Viewable by customers only
CREATE POLICY "Community posts viewable by members" ON community_posts FOR SELECT
  USING (EXISTS (
    SELECT 1 FROM players
    WHERE user_id = auth.uid()
    AND membership_tier IN ('Community', 'Full')
  ) OR post_type = 'announcement');
CREATE POLICY "Community posts insertable by members" ON community_posts FOR INSERT
  WITH CHECK (EXISTS (
    SELECT 1 FROM players
    WHERE user_id = auth.uid()
    AND membership_tier IN ('Community', 'Full')
  ));

CREATE POLICY "Comments viewable by members" ON community_comments FOR SELECT
  USING (EXISTS (SELECT 1 FROM players WHERE user_id = auth.uid() AND membership_tier IN ('Community', 'Full')));
CREATE POLICY "Comments insertable by members" ON community_comments FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM players WHERE user_id = auth.uid() AND membership_tier IN ('Community', 'Full')));

CREATE POLICY "Reactions viewable" ON community_reactions FOR SELECT USING (true);
CREATE POLICY "Reactions manageable by owner" ON community_reactions FOR ALL
  USING (player_id IN (SELECT id FROM players WHERE user_id = auth.uid()));

-- Monday calls: Full tier only
CREATE POLICY "Monday calls viewable by full tier" ON monday_calls FOR SELECT
  USING (EXISTS (SELECT 1 FROM players WHERE user_id = auth.uid() AND membership_tier = 'Full'));
CREATE POLICY "Monday attendance viewable" ON monday_call_attendance FOR SELECT USING (true);

-- ============================================
-- FUNCTIONS
-- ============================================

-- Auto-update updated_at for players
CREATE OR REPLACE FUNCTION update_players_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER players_updated_at
  BEFORE UPDATE ON players
  FOR EACH ROW
  EXECUTE FUNCTION update_players_updated_at();

-- Update reaction count on posts
CREATE OR REPLACE FUNCTION update_post_reaction_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE community_posts SET reaction_count = reaction_count + 1 WHERE id = NEW.post_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE community_posts SET reaction_count = reaction_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER reaction_count_trigger
  AFTER INSERT OR DELETE ON community_reactions
  FOR EACH ROW
  EXECUTE FUNCTION update_post_reaction_count();

-- Update comment count on posts
CREATE OR REPLACE FUNCTION update_post_comment_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE community_posts SET comment_count = comment_count + 1 WHERE id = NEW.post_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE community_posts SET comment_count = comment_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER comment_count_trigger
  AFTER INSERT OR DELETE ON community_comments
  FOR EACH ROW
  EXECUTE FUNCTION update_post_comment_count();

-- Calculate player level from XP
CREATE OR REPLACE FUNCTION calculate_player_level(xp INTEGER)
RETURNS INTEGER AS $$
DECLARE
  levels INTEGER[] := ARRAY[0, 500, 1500, 3500, 7000, 12000, 20000, 35000, 55000, 80000];
  i INTEGER;
BEGIN
  FOR i IN REVERSE 10..1 LOOP
    IF xp >= levels[i] THEN
      RETURN i;
    END IF;
  END LOOP;
  RETURN 1;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Award XP function
CREATE OR REPLACE FUNCTION award_xp(
  p_player_id UUID,
  p_amount INTEGER,
  p_reason VARCHAR(100),
  p_reference_type VARCHAR(50) DEFAULT NULL,
  p_reference_id UUID DEFAULT NULL
)
RETURNS TABLE(new_xp INTEGER, new_level INTEGER, leveled_up BOOLEAN) AS $$
DECLARE
  v_old_xp INTEGER;
  v_old_level INTEGER;
  v_new_xp INTEGER;
  v_new_level INTEGER;
BEGIN
  -- Get current XP and level
  SELECT total_xp, level INTO v_old_xp, v_old_level
  FROM players WHERE id = p_player_id;

  v_new_xp := v_old_xp + p_amount;
  v_new_level := calculate_player_level(v_new_xp);

  -- Update player
  UPDATE players SET
    total_xp = v_new_xp,
    level = v_new_level
  WHERE id = p_player_id;

  -- Log XP award
  INSERT INTO xp_log (player_id, amount, reason, new_total, reference_type, reference_id)
  VALUES (p_player_id, p_amount, p_reason, v_new_xp, p_reference_type, p_reference_id);

  RETURN QUERY SELECT v_new_xp, v_new_level, (v_new_level > v_old_level);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create auto-post for achievements
CREATE OR REPLACE FUNCTION create_achievement_post(
  p_player_id UUID,
  p_post_type VARCHAR(30),
  p_event_type VARCHAR(50),
  p_event_data JSONB
)
RETURNS UUID AS $$
DECLARE
  v_player_name VARCHAR(100);
  v_content TEXT;
  v_post_id UUID;
BEGIN
  SELECT name INTO v_player_name FROM players WHERE id = p_player_id;

  -- Generate content based on event type
  v_content := CASE p_event_type
    WHEN 'pr_bat_speed' THEN format('🔥 %s just hit %s mph bat speed!', v_player_name, p_event_data->>'value')
    WHEN 'level_up' THEN format('⬆️ %s reached Level %s - %s!', v_player_name, p_event_data->>'level', p_event_data->>'title')
    WHEN 'streak_7' THEN format('🔥 %s hit a 7-day streak!', v_player_name)
    WHEN 'streak_30' THEN format('🏆 %s hit a 30-day streak!', v_player_name)
    WHEN 'streak_100' THEN format('👑 %s hit a 100-day streak! Legend.', v_player_name)
    WHEN 'challenge_win' THEN format('🏅 %s won this week''s %s challenge!', v_player_name, p_event_data->>'challenge_name')
    WHEN 'baseline_complete' THEN format('👋 Welcome %s to the crew! Motor Profile: %s', v_player_name, p_event_data->>'motor_profile')
    ELSE format('🎉 %s achieved something awesome!', v_player_name)
  END;

  INSERT INTO community_posts (player_id, post_type, content, auto_generated, event_type, event_data)
  VALUES (p_player_id, p_post_type, v_content, TRUE, p_event_type, p_event_data)
  RETURNING id INTO v_post_id;

  RETURN v_post_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- SEED DATA: Level titles (for reference)
-- ============================================
COMMENT ON FUNCTION calculate_player_level IS
'Level progression:
  1: Rookie (0 XP)
  2: Prospect (500 XP)
  3: Contender (1,500 XP)
  4: Competitor (3,500 XP)
  5: Varsity (7,000 XP)
  6: All-Conference (12,000 XP)
  7: All-State (20,000 XP)
  8: D1 Commit (35,000 XP)
  9: Pro Prospect (55,000 XP)
  10: Barrel King (80,000 XP)';
