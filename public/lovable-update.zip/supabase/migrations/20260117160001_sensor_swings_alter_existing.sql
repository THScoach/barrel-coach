-- ============================================================================
-- SENSOR SWINGS ALTER - FOR EXISTING INSTALLS
-- Run this if sensor_swings table already exists
-- ============================================================================

-- Add missing columns (IF NOT EXISTS is idempotent)
ALTER TABLE sensor_swings ADD COLUMN IF NOT EXISTS dk_swing_id TEXT;
ALTER TABLE sensor_swings ADD COLUMN IF NOT EXISTS occurred_at TIMESTAMPTZ DEFAULT NOW();
ALTER TABLE sensor_swings ADD COLUMN IF NOT EXISTS swing_plane_tilt_deg DECIMAL(5,1);
ALTER TABLE sensor_swings ADD COLUMN IF NOT EXISTS invalid_reason VARCHAR(50);
ALTER TABLE sensor_swings ADD COLUMN IF NOT EXISTS warnings TEXT[];
ALTER TABLE sensor_swings ADD COLUMN IF NOT EXISTS raw_dk_data JSONB;

-- FIX #2: Ensure ratio column has 2 decimal precision
-- If column exists with wrong precision, this alters it
-- For fresh columns this sets correct precision
DO $$
BEGIN
  -- Only alter if column exists and type is wrong
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'sensor_swings' AND column_name = 'hand_to_bat_ratio'
  ) THEN
    ALTER TABLE sensor_swings
      ALTER COLUMN hand_to_bat_ratio TYPE DECIMAL(5,2);
  END IF;
END $$;

-- Drop old composite index if exists (without swing_number)
DROP INDEX IF EXISTS ux_swings_composite_old;

-- Rename old index if it exists with different columns
DO $$
BEGIN
  -- Check if the old index exists and doesn't include swing_number
  IF EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE indexname = 'ux_swings_composite'
    AND indexdef NOT LIKE '%swing_number%'
  ) THEN
    DROP INDEX ux_swings_composite;
  END IF;
END $$;

-- Create new composite index with swing_number (FIX #3)
-- This is idempotent - will skip if already exists with correct columns
CREATE UNIQUE INDEX IF NOT EXISTS ux_swings_composite
ON sensor_swings(player_id, session_id, occurred_at, bat_speed_mph, swing_number);

-- Primary dedupe index
CREATE UNIQUE INDEX IF NOT EXISTS ux_swings_dk_id
ON sensor_swings(player_id, dk_swing_id)
WHERE dk_swing_id IS NOT NULL;

-- Query indexes
CREATE INDEX IF NOT EXISTS idx_swings_session ON sensor_swings(session_id);
CREATE INDEX IF NOT EXISTS idx_swings_player_date ON sensor_swings(player_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_swings_player_valid ON sensor_swings(player_id, is_valid) WHERE is_valid = TRUE;

-- ============================================================================
-- ENSURE RLS IS ENABLED
-- ============================================================================

ALTER TABLE sensor_swings ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist (to recreate cleanly)
DROP POLICY IF EXISTS sensor_swings_player_select ON sensor_swings;
DROP POLICY IF EXISTS sensor_swings_coach_select ON sensor_swings;
DROP POLICY IF EXISTS sensor_swings_service_insert ON sensor_swings;

-- Recreate policies
CREATE POLICY sensor_swings_player_select ON sensor_swings
  FOR SELECT USING (
    player_id IN (
      SELECT id FROM players WHERE user_id = auth.uid()
    )
  );

CREATE POLICY sensor_swings_coach_select ON sensor_swings
  FOR SELECT USING (
    player_id IN (
      SELECT id FROM players WHERE coach_id = auth.uid()
    )
  );

CREATE POLICY sensor_swings_service_insert ON sensor_swings
  FOR INSERT WITH CHECK (TRUE);
