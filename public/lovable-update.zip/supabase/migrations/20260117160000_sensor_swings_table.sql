-- ============================================================================
-- SENSOR SWINGS TABLE - DIAMOND KINETICS NORMALIZED DATA
-- Production-ready with all dedupe indexes
-- ============================================================================

-- Sensor swings table (complete)
CREATE TABLE IF NOT EXISTS sensor_swings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  player_id UUID NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  session_id UUID NOT NULL REFERENCES sensor_sessions(id) ON DELETE CASCADE,

  -- DK identifiers
  dk_swing_id TEXT,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  swing_number INTEGER,

  -- Measured (rounded for dedupe)
  bat_speed_mph DECIMAL(5,1),
  hand_speed_mph DECIMAL(5,1),
  trigger_to_impact_ms INTEGER,
  attack_angle_deg DECIMAL(5,1),
  attack_direction_deg DECIMAL(5,1),
  swing_plane_tilt_deg DECIMAL(5,1),
  impact_location_x DECIMAL(5,3),
  impact_location_y DECIMAL(5,3),
  impact_location_z DECIMAL(5,3),
  applied_power DECIMAL(8,1),
  max_acceleration DECIMAL(8,1),

  -- Derived (FIX #2: ratio needs DECIMAL(5,2) for 2 decimal precision)
  hand_to_bat_ratio DECIMAL(5,2),

  -- Quality
  is_valid BOOLEAN DEFAULT TRUE,
  invalid_reason VARCHAR(50),
  warnings TEXT[],

  -- Raw (with meta)
  raw_dk_data JSONB,

  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- DEDUPE INDEXES
-- ============================================================================

-- Primary: DK swing ID (if provided)
CREATE UNIQUE INDEX IF NOT EXISTS ux_swings_dk_id
ON sensor_swings(player_id, dk_swing_id)
WHERE dk_swing_id IS NOT NULL;

-- FIX #3: Fallback composite - include swing_number for dense burst safety
-- Without swing_number, multiple swings with same timestamp bucket + speed would collide
CREATE UNIQUE INDEX IF NOT EXISTS ux_swings_composite
ON sensor_swings(player_id, session_id, occurred_at, bat_speed_mph, swing_number);

-- ============================================================================
-- QUERY INDEXES
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_swings_session ON sensor_swings(session_id);
CREATE INDEX IF NOT EXISTS idx_swings_player_date ON sensor_swings(player_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_swings_player_valid ON sensor_swings(player_id, is_valid) WHERE is_valid = TRUE;

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================

ALTER TABLE sensor_swings ENABLE ROW LEVEL SECURITY;

-- Players can view their own swings
CREATE POLICY sensor_swings_player_select ON sensor_swings
  FOR SELECT USING (
    player_id IN (
      SELECT id FROM players WHERE user_id = auth.uid()
    )
  );

-- Coaches can view swings for their players
CREATE POLICY sensor_swings_coach_select ON sensor_swings
  FOR SELECT USING (
    player_id IN (
      SELECT id FROM players WHERE coach_id = auth.uid()
    )
  );

-- Service role can insert (for API)
CREATE POLICY sensor_swings_service_insert ON sensor_swings
  FOR INSERT WITH CHECK (TRUE);

-- ============================================================================
-- UPDATE SESSION AGGREGATES FUNCTION
-- ============================================================================

CREATE OR REPLACE FUNCTION update_session_swing_aggregates()
RETURNS TRIGGER AS $$
DECLARE
  v_total_swings INTEGER;
  v_avg_bat_speed DECIMAL;
  v_max_bat_speed DECIMAL;
  v_avg_ratio DECIMAL;
  v_timing_cv DECIMAL;
BEGIN
  -- Calculate aggregates for the session
  SELECT
    COUNT(*),
    AVG(bat_speed_mph),
    MAX(bat_speed_mph),
    AVG(hand_to_bat_ratio),
    CASE
      WHEN AVG(trigger_to_impact_ms) > 0 AND COUNT(*) > 1
      THEN STDDEV(trigger_to_impact_ms) / AVG(trigger_to_impact_ms) * 100
      ELSE NULL
    END
  INTO v_total_swings, v_avg_bat_speed, v_max_bat_speed, v_avg_ratio, v_timing_cv
  FROM sensor_swings
  WHERE session_id = NEW.session_id AND is_valid = TRUE;

  -- Update the session
  UPDATE sensor_sessions
  SET
    total_swings = v_total_swings,
    avg_bat_speed = ROUND(v_avg_bat_speed::NUMERIC, 1),
    max_bat_speed = v_max_bat_speed,
    avg_hand_to_bat_ratio = ROUND(v_avg_ratio::NUMERIC, 2),
    timing_variance_pct = ROUND(v_timing_cv::NUMERIC, 1),
    updated_at = NOW()
  WHERE id = NEW.session_id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update session aggregates on swing insert
DROP TRIGGER IF EXISTS trg_update_session_aggregates ON sensor_swings;
CREATE TRIGGER trg_update_session_aggregates
  AFTER INSERT ON sensor_swings
  FOR EACH ROW
  EXECUTE FUNCTION update_session_swing_aggregates();

-- ============================================================================
-- COMMENTS
-- ============================================================================

COMMENT ON TABLE sensor_swings IS 'Normalized swing data from Diamond Kinetics sensor';
COMMENT ON COLUMN sensor_swings.dk_swing_id IS 'Original DK swing UUID for deduplication';
COMMENT ON COLUMN sensor_swings.occurred_at IS 'Swing timestamp rounded to 100ms for dedupe';
COMMENT ON COLUMN sensor_swings.raw_dk_data IS 'Original DK payload with normalizer metadata';
COMMENT ON COLUMN sensor_swings.invalid_reason IS 'Why swing was rejected: missing_bat_speed, below_speed_threshold, timing_too_fast, timing_too_slow';
COMMENT ON COLUMN sensor_swings.warnings IS 'Non-fatal issues: hand_speed_low';
