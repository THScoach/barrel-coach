// ============================================================================
// DIAMOND KINETICS NORMALIZER - PRODUCTION
// All 8 tweaks applied + production hardening fixes
// ============================================================================

import type { CanonicalSwing, NormalizeOptions, NormalizeBatchResult } from './types';

const NORMALIZER_VERSION = '1.0.0';

// ============================================================================
// FIELD ALIASES
// ============================================================================

const ALIASES: Record<string, string[]> = {
  // Speeds
  bat_speed_mph: ['speedBarrelMax', 'batSpeed', 'bat_speed_mph'],
  hand_speed_mph: ['speedHandsMax', 'speedHandMax', 'handSpeed', 'hand_speed_mph'],

  // Timing
  trigger_to_impact_ms: ['quicknessTriggerImpact', 'triggerToImpactTime', 'triggerToImpactTimeMs'],

  // Attack angles
  attack_angle_deg: ['swingPlaneSteepnessAngle', 'attackAngle', 'attack_angle_deg'],
  attack_direction_deg: ['swingPlaneHeadingAngle', 'attackDirection', 'attack_direction_deg'],
  swing_plane_tilt_deg: ['swingPlaneTiltAngle', 'swingPathTilt'],

  // Impact location
  impact_location_x: ['impactLocX', 'impactLocationX'],
  impact_location_y: ['impactLocY', 'impactLocationY'],
  impact_location_z: ['impactLocZ', 'impactLocationZ'],

  // Power
  applied_power: ['appliedPower', 'powerApplied'],
  max_acceleration: ['maxAcceleration', 'accelMax'],

  // Identifiers
  dk_swing_id: ['id', 'swingId', 'uuid', 'swing_id'],
  occurred_at: ['occurredAt', 'timestamp', 'createdAt', 'created_at'],
};

// ============================================================================
// HELPERS
// ============================================================================

function pickNumber(obj: unknown, keys: string[]): number | null {
  if (!obj || typeof obj !== 'object') return null;
  const record = obj as Record<string, unknown>;

  for (const key of keys) {
    const value = record[key];
    if (typeof value === 'number' && Number.isFinite(value)) {
      return value;
    }
  }
  return null;
}

function pickString(obj: unknown, keys: string[]): string | null {
  if (!obj || typeof obj !== 'object') return null;
  const record = obj as Record<string, unknown>;

  for (const key of keys) {
    const value = record[key];
    if (typeof value === 'string' && value.length > 0) {
      return value;
    }
  }
  return null;
}

/**
 * FIX #1: Pick timestamp that could be string OR number (epoch)
 * Don't pre-filter with pickString — epochs are numbers
 */
function pickTimestamp(obj: unknown): string | number | null {
  if (!obj || typeof obj !== 'object') return null;
  const record = obj as Record<string, unknown>;

  // Check all known timestamp field names
  const timestampKeys = ['occurredAt', 'occurred_at', 'timestamp', 'createdAt', 'created_at'];

  for (const key of timestampKeys) {
    const value = record[key];
    // Accept string (ISO) or number (epoch)
    if (typeof value === 'string' && value.length > 0) {
      return value;
    }
    if (typeof value === 'number' && Number.isFinite(value) && value > 0) {
      return value;
    }
  }
  return null;
}

function getField<T>(
  obj: unknown,
  canonicalName: string,
  picker: (obj: unknown, keys: string[]) => T | null
): T | null {
  const aliases = ALIASES[canonicalName] || [canonicalName];
  return picker(obj, aliases);
}

// ============================================================================
// TWEAK #1: PARSE OCCURRED_AT (handles epoch ms/sec/ISO)
// ============================================================================

function parseOccurredAt(value: unknown, fallback: string): string {
  // Already ISO string
  if (typeof value === 'string' && value.length > 0) {
    const parsed = new Date(value);
    if (!isNaN(parsed.getTime())) {
      return parsed.toISOString();
    }
  }

  // Epoch milliseconds (13 digits)
  if (typeof value === 'number' && value > 1000000000000) {
    return new Date(value).toISOString();
  }

  // Epoch seconds (10 digits)
  if (typeof value === 'number' && value > 1000000000 && value < 10000000000) {
    return new Date(value * 1000).toISOString();
  }

  // Fallback
  return fallback;
}

// ============================================================================
// TWEAK #2 & #3: ROUNDING HELPERS (for dedupe)
// ============================================================================

/**
 * Round timestamp to nearest 100ms for dedupe consistency
 */
function roundTo100ms(isoString: string): string {
  const date = new Date(isoString);
  const ms = date.getTime();
  const rounded = Math.round(ms / 100) * 100;
  return new Date(rounded).toISOString();
}

/**
 * Round number to 1 decimal place (for bat/hand speeds)
 */
function roundTo1Decimal(value: number | null): number | null {
  if (value === null) return null;
  return Math.round(value * 10) / 10;
}

/**
 * FIX #2: Round number to 2 decimal places (for ratios)
 * Ratio needs finer precision: 1.15 vs 1.20 matters in scoring
 */
function roundTo2Decimals(value: number | null): number | null {
  if (value === null) return null;
  return Math.round(value * 100) / 100;
}

// ============================================================================
// VALIDATION
// ============================================================================

interface ValidationResult {
  is_valid: boolean;
  invalid_reason: string | null;
  warnings: string[];
}

function validateSwing(
  bat_speed: number | null,
  hand_speed: number | null,
  trigger_to_impact: number | null
): ValidationResult {
  const warnings: string[] = [];

  // HARD FAIL: Must have bat speed
  if (bat_speed === null) {
    return { is_valid: false, invalid_reason: 'missing_bat_speed', warnings };
  }

  // HARD FAIL: Waggle/bunt filter
  if (bat_speed < 30) {
    return { is_valid: false, invalid_reason: 'below_speed_threshold', warnings };
  }

  // TWEAK #5: Hand speed is WARNING, not invalid
  // (Youth bats + weird swings can show low hand speed while bat speed is valid)
  if (hand_speed !== null && hand_speed < 20) {
    warnings.push('hand_speed_low');
  }

  // Timing sanity
  if (trigger_to_impact !== null) {
    if (trigger_to_impact < 80) {
      return { is_valid: false, invalid_reason: 'timing_too_fast', warnings };
    }
    if (trigger_to_impact > 350) {
      return { is_valid: false, invalid_reason: 'timing_too_slow', warnings };
    }
  }

  return { is_valid: true, invalid_reason: null, warnings };
}

// ============================================================================
// MAIN NORMALIZER
// ============================================================================

export function normalizeDKSwing(
  dkSwing: unknown,
  opts: NormalizeOptions
): CanonicalSwing {
  const now = new Date().toISOString();

  // DK payloads sometimes nest metrics
  const metrics = (dkSwing as Record<string, unknown>)?.metrics ?? dkSwing;

  // Extract measured values
  const bat_speed_raw = getField(metrics, 'bat_speed_mph', pickNumber);
  const hand_speed_raw = getField(metrics, 'hand_speed_mph', pickNumber);
  const trigger_to_impact_ms = getField(metrics, 'trigger_to_impact_ms', pickNumber);
  const attack_angle_deg = getField(metrics, 'attack_angle_deg', pickNumber);
  const attack_direction_deg = getField(metrics, 'attack_direction_deg', pickNumber);
  const swing_plane_tilt_deg = getField(metrics, 'swing_plane_tilt_deg', pickNumber);
  const impact_location_x = getField(metrics, 'impact_location_x', pickNumber);
  const impact_location_y = getField(metrics, 'impact_location_y', pickNumber);
  const impact_location_z = getField(metrics, 'impact_location_z', pickNumber);
  const applied_power = getField(metrics, 'applied_power', pickNumber);
  const max_acceleration = getField(metrics, 'max_acceleration', pickNumber);

  // Extract identifiers
  const dk_swing_id = getField(dkSwing, 'dk_swing_id', pickString);

  // FIX #1: Use pickTimestamp (handles string OR number epochs)
  const raw_timestamp = pickTimestamp(dkSwing) ?? pickTimestamp(metrics);
  const occurred_at_raw = parseOccurredAt(raw_timestamp, opts.fallback_timestamp ?? now);

  // TWEAK #2 & #3: Round for dedupe consistency
  const occurred_at = roundTo100ms(occurred_at_raw);
  const bat_speed_mph = roundTo1Decimal(bat_speed_raw);
  const hand_speed_mph = roundTo1Decimal(hand_speed_raw);

  // FIX #2: Calculate ratio with 2 decimal precision (1.15 vs 1.20 matters)
  const hand_to_bat_ratio =
    bat_speed_mph !== null && hand_speed_mph !== null && hand_speed_mph > 0
      ? roundTo2Decimals(bat_speed_mph / hand_speed_mph)
      : null;

  // Validate
  const validation = validateSwing(bat_speed_mph, hand_speed_mph, trigger_to_impact_ms);

  // TWEAK #4: Add raw_meta (FIX #6: include occurred_at_raw here)
  const raw_meta = {
    received_at: now,
    normalizer_version: NORMALIZER_VERSION,
    dk_sdk_version: opts.dk_sdk_version ?? null,
    occurred_at_raw, // Store original timestamp for debugging
  };

  return {
    // Identifiers
    dk_swing_id,
    session_id: opts.session_id,
    occurred_at,
    occurred_at_raw,
    swing_number: opts.swing_number ?? null,

    // Measured (rounded)
    bat_speed_mph,
    hand_speed_mph,
    trigger_to_impact_ms,
    attack_angle_deg: roundTo1Decimal(attack_angle_deg),
    attack_direction_deg: roundTo1Decimal(attack_direction_deg),
    swing_plane_tilt_deg: roundTo1Decimal(swing_plane_tilt_deg),
    impact_location_x: roundTo1Decimal(impact_location_x),
    impact_location_y: roundTo1Decimal(impact_location_y),
    impact_location_z: roundTo1Decimal(impact_location_z),
    applied_power: roundTo1Decimal(applied_power),
    max_acceleration: roundTo1Decimal(max_acceleration),

    // Derived
    hand_to_bat_ratio,

    // Quality
    is_valid: validation.is_valid,
    invalid_reason: validation.invalid_reason,
    warnings: validation.warnings,

    // Raw (with meta including occurred_at_raw)
    raw: dkSwing,
    raw_meta,
  };
}

/**
 * Normalize a batch of swings and categorize results
 */
export function normalizeDKSwingBatch(
  dkSwings: unknown[],
  session_id: string,
  dk_sdk_version?: string
): NormalizeBatchResult {
  const valid: CanonicalSwing[] = [];
  const invalid: CanonicalSwing[] = [];
  const warnings: CanonicalSwing[] = [];

  for (let i = 0; i < dkSwings.length; i++) {
    const normalized = normalizeDKSwing(dkSwings[i], {
      session_id,
      swing_number: i + 1,
      dk_sdk_version,
    });

    if (normalized.is_valid) {
      valid.push(normalized);
      if (normalized.warnings.length > 0) {
        warnings.push(normalized);
      }
    } else {
      invalid.push(normalized);
    }
  }

  return { valid, invalid, warnings };
}
