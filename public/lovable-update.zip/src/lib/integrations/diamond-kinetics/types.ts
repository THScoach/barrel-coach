// ============================================================================
// DIAMOND KINETICS NORMALIZER - CANONICAL TYPES
// Production-ready with all 8 tweaks applied
// ============================================================================

export interface CanonicalSwing {
  // Identifiers
  dk_swing_id: string | null;
  session_id: string;
  occurred_at: string;           // ISO timestamp (rounded to 100ms)
  occurred_at_raw: string;       // Original timestamp before rounding
  swing_number: number | null;

  // Measured (rounded for dedupe consistency)
  bat_speed_mph: number | null;  // Rounded to 0.1
  hand_speed_mph: number | null; // Rounded to 0.1
  trigger_to_impact_ms: number | null;
  attack_angle_deg: number | null;
  attack_direction_deg: number | null;
  swing_plane_tilt_deg: number | null;
  impact_location_x: number | null;
  impact_location_y: number | null;
  impact_location_z: number | null;
  applied_power: number | null;
  max_acceleration: number | null;

  // Derived
  hand_to_bat_ratio: number | null;

  // Quality
  is_valid: boolean;
  invalid_reason: string | null;
  warnings: string[];

  // Raw (with metadata)
  raw: unknown;
  raw_meta: {
    received_at: string;
    normalizer_version: string;
    dk_sdk_version: string | null;
    occurred_at_raw: string;
  };
}

export interface NormalizeOptions {
  session_id: string;
  swing_number?: number | null;
  fallback_timestamp?: string;
  dk_sdk_version?: string | null;
}

export interface NormalizeBatchResult {
  valid: CanonicalSwing[];
  invalid: CanonicalSwing[];
  warnings: CanonicalSwing[];  // Valid but with warnings
}

export interface SyncRequestBody {
  sessionId: string;
  swings: unknown[];
  dk_sdk_version?: string;
}

export interface SyncResponse {
  success: boolean;
  ingest_id: string;
  processed: number;
  duplicates: number;
  rejected: number;
  warnings: number;
  total_received: number;
}
