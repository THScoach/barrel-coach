// ============================================================================
// KWON-STYLE SENSOR ANALYSIS - TYPE DEFINITIONS
// "We don't add, we unlock. Measure to understand, not enforce."
// ============================================================================

// Confidence levels for predictions
export type ConfidenceLevel = 'HIGH' | 'MEDIUM' | 'LOW';

// Raw swing data from Diamond Kinetics sensor
export interface DKSwingData {
  swingId: string;
  timestamp: Date;

  // Measured facts (always available from sensor)
  batSpeed: number;           // mph
  handSpeed: number;          // mph
  timeToContact: number;      // ms from trigger to impact
  attackAngle: number;        // degrees
  attackDirection: number;    // degrees (-30 pull to +30 oppo)

  // Optional measured fields (when sensor captures them)
  rotationalAcceleration?: number;  // deg/s²
  onPlaneEfficiency?: number;       // 0-100%
  connectionAngle?: number;         // degrees at contact
  impactMomentum?: number;          // kg*m/s

  // Impact location (if measured)
  impactLocX?: number;        // -1 to 1 (toe to heel)
  impactLocY?: number;        // -1 to 1 (bottom to top)
}

// ============================================================================
// MEASURED FACTS (from sensor - 100% confidence)
// ============================================================================

export interface SensorFacts {
  // Session aggregates
  swingCount: number;

  // Bat speed facts
  batSpeedMax: number;
  batSpeedMean: number;
  batSpeedStdDev: number;

  // Hand speed facts
  handSpeedMax: number;
  handSpeedMean: number;
  handSpeedStdDev: number;

  // Timing facts
  timeToContactMean: number;
  timeToContactStdDev: number;
  timingCV: number;           // Coefficient of variation

  // Attack angle facts
  attackAngleMean: number;
  attackAngleStdDev: number;

  // Attack direction facts
  attackDirectionMean: number;
  attackDirectionStdDev: number;

  // Derived measurements
  handToBatRatio: number;     // batSpeed / handSpeed

  // Optional if sensor captures
  rotationalAccelerationMean?: number;
  onPlaneEfficiencyMean?: number;
  connectionAngleMean?: number;
}

// ============================================================================
// PREDICTIONS WITH CONFIDENCE LEVELS
// ============================================================================

export interface Prediction<T> {
  value: T;
  confidence: ConfidenceLevel;
  reasoning: string;
}

// Release quality prediction (HIGH confidence - derived from hand-to-bat ratio)
export interface ReleasePrediction {
  handToBatRatio: number;
  quality: 'excellent' | 'good' | 'average' | 'needs_work';
  percentile: number;             // Where they rank vs population
  potentialUnlock: number;        // mph they could gain with better release
  confidence: ConfidenceLevel;    // HIGH - direct calculation from sensor
  reasoning: string;
}

// Timing prediction (MEDIUM confidence - inferred from variance patterns)
export interface TimingPrediction {
  consistencyScore: number;       // 0-100
  tempoCategory: 'quick' | 'moderate' | 'deliberate';
  adjustability: 'rigid' | 'adaptable' | 'fluid';
  predictedTimingWindow: number;  // ms window of comfortable timing
  potentialUnlock: number;        // mph potential with better timing
  confidence: ConfidenceLevel;    // MEDIUM
  reasoning: string;
}

// Upstream energy prediction (LOW confidence - need video to confirm)
export interface UpstreamPrediction {
  estimatedHipContribution: number;       // 0-100%
  estimatedTorsoContribution: number;     // 0-100%
  likelyKineticChainBreaks: string[];     // Possible break points
  potentialUnlock: number;                // mph potential with better sequencing
  confidence: ConfidenceLevel;            // LOW - speculation without video
  reasoning: string;
  needsVideoFor: string[];                // What video would confirm
}

// ============================================================================
// KINETIC POTENTIAL
// ============================================================================

export interface KineticPotential {
  currentBatSpeed: number;        // What they hit now
  projectedPotential: number;     // What they could hit
  totalUnlock: number;            // Difference

  // Breakdown of where potential comes from
  releaseUnlock: Prediction<number>;
  timingUnlock: Prediction<number>;
  upstreamUnlock: Prediction<number>;

  // Overall confidence in projection
  overallConfidence: ConfidenceLevel;

  // What would confirm/improve our predictions
  validationNeeds: string[];
}

// ============================================================================
// POSSIBLE LEAKS
// ============================================================================

export type LeakProbability = 'likely' | 'possible' | 'speculative';

export interface PossibleLeak {
  leakType: string;
  category: 'release' | 'timing' | 'upstream' | 'path';
  description: string;
  probability: LeakProbability;
  evidence: string;               // What in the data suggests this
  potentialGain: number;          // mph if fixed
  howToConfirm: string;           // What would validate this leak
}

// ============================================================================
// 4B SCORES FROM SENSOR
// ============================================================================

// BAT score (HIGH confidence - direct from sensor)
export interface BatScore {
  overall: number;                // 0-100
  batSpeedScore: number;
  handSpeedScore: number;
  releaseScore: number;           // Hand-to-bat ratio quality
  accelerationScore?: number;     // If sensor provides
  confidence: ConfidenceLevel;    // HIGH
}

// BRAIN score (MEDIUM confidence - inferred from patterns)
export interface BrainScore {
  overall: number;                // 0-100
  timingConsistency: number;      // From CV of time-to-contact
  pathConsistency: number;        // From attack angle/direction variance
  zoneAdaptability: number;       // Inferred from attack direction range
  confidence: ConfidenceLevel;    // MEDIUM
  reasoning: string;
}

// BODY score (LOW confidence - prediction, need video)
export interface BodyScore {
  overall: number;                // 0-100
  estimatedSequencing: number;    // Inferred from acceleration patterns
  estimatedSeparation: number;    // Inferred from hand/bat relationship
  estimatedGroundForce: number;   // Speculative without force plate
  confidence: ConfidenceLevel;    // LOW
  reasoning: string;
  needsVideoFor: string[];        // What video would tell us
}

// BALL score (from launch monitor, not sensor)
export interface BallScore {
  overall: number;                // 0-100
  available: boolean;             // Do we have launch monitor data?
  exitVelocity?: number;
  launchAngle?: number;
  hardHitRate?: number;
  confidence: ConfidenceLevel;    // HIGH if available, N/A if not
}

// Complete 4B assessment from sensor
export interface FourBFromSensor {
  bat: BatScore;
  brain: BrainScore;
  body: BodyScore;
  ball: BallScore;

  // Composite
  compositeScore: number;
  confidenceNote: string;         // Explanation of confidence levels
}

// ============================================================================
// MOTOR PROFILE TYPES
// ============================================================================

export type MotorProfile = 'Spinner' | 'Slingshotter' | 'Whipper' | 'Titan' | 'Unknown';

// ============================================================================
// COMPLETE KWON ANALYSIS RESULT
// ============================================================================

export interface KwonAnalysis {
  sessionId: string;
  playerId: string;
  analysisDate: Date;

  // What we measured (facts)
  sensorFacts: SensorFacts;

  // What we predict (with confidence)
  releasePrediction: ReleasePrediction;
  timingPrediction: TimingPrediction;
  upstreamPrediction: UpstreamPrediction;

  // How much is hiding
  kineticPotential: KineticPotential;

  // What might be leaking
  possibleLeaks: PossibleLeak[];

  // 4B scores from sensor
  fourBScores: FourBFromSensor;

  // Motor profile classification
  motorProfile: MotorProfile;

  // Priority actions
  priorityFocus: string;
  secondaryFocus: string;

  // Metadata
  swingsAnalyzed: number;
  dataQuality: 'excellent' | 'good' | 'limited';
}

// ============================================================================
// POPULATION BASELINES (for percentile calculations)
// ============================================================================

export interface PopulationBaseline {
  ageGroup: string;
  level: 'youth' | 'high_school' | 'college' | 'pro';

  batSpeed: { p10: number; p50: number; p90: number };
  handSpeed: { p10: number; p50: number; p90: number };
  handToBatRatio: { p10: number; p50: number; p90: number };
  timingCV: { p10: number; p50: number; p90: number };
  attackAngle: { p10: number; p50: number; p90: number };
}

// Default baselines by level
export const POPULATION_BASELINES: Record<string, PopulationBaseline> = {
  'youth_12u': {
    ageGroup: '12u',
    level: 'youth',
    batSpeed: { p10: 35, p50: 45, p90: 55 },
    handSpeed: { p10: 28, p50: 36, p90: 44 },
    handToBatRatio: { p10: 1.15, p50: 1.25, p90: 1.35 },
    timingCV: { p10: 0.03, p50: 0.08, p90: 0.15 },
    attackAngle: { p10: 5, p50: 12, p90: 20 },
  },
  'youth_14u': {
    ageGroup: '14u',
    level: 'youth',
    batSpeed: { p10: 45, p50: 55, p90: 65 },
    handSpeed: { p10: 36, p50: 44, p90: 52 },
    handToBatRatio: { p10: 1.18, p50: 1.26, p90: 1.35 },
    timingCV: { p10: 0.03, p50: 0.07, p90: 0.12 },
    attackAngle: { p10: 6, p50: 13, p90: 22 },
  },
  'high_school': {
    ageGroup: '15-18',
    level: 'high_school',
    batSpeed: { p10: 55, p50: 68, p90: 78 },
    handSpeed: { p10: 44, p50: 54, p90: 62 },
    handToBatRatio: { p10: 1.20, p50: 1.28, p90: 1.38 },
    timingCV: { p10: 0.02, p50: 0.06, p90: 0.10 },
    attackAngle: { p10: 8, p50: 15, p90: 25 },
  },
  'college': {
    ageGroup: '18-22',
    level: 'college',
    batSpeed: { p10: 68, p50: 76, p90: 85 },
    handSpeed: { p10: 54, p50: 60, p90: 68 },
    handToBatRatio: { p10: 1.22, p50: 1.30, p90: 1.40 },
    timingCV: { p10: 0.02, p50: 0.05, p90: 0.08 },
    attackAngle: { p10: 10, p50: 18, p90: 28 },
  },
  'pro': {
    ageGroup: '22+',
    level: 'pro',
    batSpeed: { p10: 72, p50: 78, p90: 88 },
    handSpeed: { p10: 56, p50: 62, p90: 70 },
    handToBatRatio: { p10: 1.24, p50: 1.32, p90: 1.42 },
    timingCV: { p10: 0.01, p50: 0.04, p90: 0.07 },
    attackAngle: { p10: 12, p50: 20, p90: 30 },
  },
};
