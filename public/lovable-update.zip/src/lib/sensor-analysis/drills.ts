// ============================================================================
// DRILL RECOMMENDATIONS
// Connect leak detection to drill content library
// ============================================================================

import type { PossibleLeak } from './types';

// ============================================================================
// TYPES
// ============================================================================

export interface DrillRecommendation {
  drill_id: string;
  name: string;
  description: string;
  video_url: string;
  duration_minutes: number;
  equipment: string[];
  leak_targets: string[];
  priority: number; // 1 = highest
}

// ============================================================================
// DRILL LIBRARY
// ============================================================================

const DRILL_MAPPINGS: Record<string, DrillRecommendation> = {
  // RELEASE DRILLS
  'wrist-snap-series': {
    drill_id: 'drill_wrist_snap_001',
    name: 'Wrist Snap Series',
    description: 'Improve hand-to-bat energy transfer through barrel whip',
    video_url: '/drills/wrist-snap-series',
    duration_minutes: 10,
    equipment: ['bat', 'tee'],
    leak_targets: ['early_release', 'suboptimal_release', 'release_efficiency'],
    priority: 1,
  },
  'lag-and-drag': {
    drill_id: 'drill_lag_drag_001',
    name: 'Lag and Drag Drill',
    description: 'Create better barrel lag for explosive release',
    video_url: '/drills/lag-and-drag',
    duration_minutes: 12,
    equipment: ['bat', 'resistance_band'],
    leak_targets: ['early_release', 'release_efficiency'],
    priority: 2,
  },
  'towel-whip': {
    drill_id: 'drill_towel_whip_001',
    name: 'Towel Whip Drill',
    description: 'Feel proper wrist snap timing without a bat',
    video_url: '/drills/towel-whip',
    duration_minutes: 5,
    equipment: ['towel'],
    leak_targets: ['early_release', 'suboptimal_release'],
    priority: 3,
  },

  // TIMING DRILLS
  'tempo-training': {
    drill_id: 'drill_tempo_001',
    name: 'Tempo Training',
    description: 'Build consistent timing and rhythm through deliberate practice',
    video_url: '/drills/tempo-training',
    duration_minutes: 15,
    equipment: ['bat', 'soft_toss_balls'],
    leak_targets: ['inconsistent_load', 'timing_variance'],
    priority: 1,
  },
  'metronome-swings': {
    drill_id: 'drill_metronome_001',
    name: 'Metronome Swings',
    description: 'Use audio cue to lock in consistent timing',
    video_url: '/drills/metronome-swings',
    duration_minutes: 10,
    equipment: ['bat', 'metronome_app'],
    leak_targets: ['inconsistent_load', 'timing_variance'],
    priority: 2,
  },
  'rhythm-load': {
    drill_id: 'drill_rhythm_load_001',
    name: 'Rhythm Load Drill',
    description: 'Smooth load-to-launch sequence',
    video_url: '/drills/rhythm-load',
    duration_minutes: 8,
    equipment: ['bat'],
    leak_targets: ['inconsistent_load'],
    priority: 3,
  },

  // PATH DRILLS
  'path-control': {
    drill_id: 'drill_path_001',
    name: 'Path Control Series',
    description: 'Tighten your swing path for consistent contact',
    video_url: '/drills/path-control',
    duration_minutes: 12,
    equipment: ['bat', 'tee', 'net'],
    leak_targets: ['variable_path', 'path_variance', 'scattered_direction'],
    priority: 1,
  },
  'plane-trainer': {
    drill_id: 'drill_plane_001',
    name: 'Swing Plane Trainer',
    description: 'Stay on plane through the zone',
    video_url: '/drills/plane-trainer',
    duration_minutes: 10,
    equipment: ['bat', 'swing_plane_trainer'],
    leak_targets: ['variable_path', 'path_variance'],
    priority: 2,
  },

  // UPSTREAM / CONNECTION DRILLS
  'connection-series': {
    drill_id: 'drill_connection_001',
    name: 'Connection Series',
    description: 'Restore kinetic chain connection from ground up',
    video_url: '/drills/connection-series',
    duration_minutes: 12,
    equipment: ['bat', 'resistance_band'],
    leak_targets: ['upstream_limitation', 'low_rotation'],
    priority: 1,
  },
  'hip-lead': {
    drill_id: 'drill_hip_lead_001',
    name: 'Hip Lead Drill',
    description: 'Fire the hips first for proper sequencing',
    video_url: '/drills/hip-lead',
    duration_minutes: 8,
    equipment: ['bat'],
    leak_targets: ['upstream_limitation', 'low_rotation'],
    priority: 2,
  },
  'separation-drill': {
    drill_id: 'drill_separation_001',
    name: 'Hip-Shoulder Separation',
    description: 'Create X-factor for more power',
    video_url: '/drills/separation-drill',
    duration_minutes: 10,
    equipment: ['bat', 'resistance_band'],
    leak_targets: ['upstream_limitation'],
    priority: 3,
  },
};

// ============================================================================
// LEAK-TO-DRILL MAPPING
// ============================================================================

const LEAK_DRILL_TAGS: Record<string, string[]> = {
  // Release leaks
  early_release: ['wrist-snap-series', 'lag-and-drag', 'towel-whip'],
  suboptimal_release: ['wrist-snap-series', 'towel-whip'],
  release_efficiency: ['wrist-snap-series', 'lag-and-drag'],

  // Timing leaks
  inconsistent_load: ['tempo-training', 'metronome-swings', 'rhythm-load'],
  timing_variance: ['tempo-training', 'metronome-swings'],

  // Path leaks
  variable_path: ['path-control', 'plane-trainer'],
  path_variance: ['path-control', 'plane-trainer'],
  scattered_direction: ['path-control'],

  // Upstream leaks
  upstream_limitation: ['connection-series', 'hip-lead', 'separation-drill'],
  low_rotation: ['connection-series', 'hip-lead'],
};

// ============================================================================
// FUNCTIONS
// ============================================================================

/**
 * Get drill recommendations for identified leaks
 * Only prescribes drills for HIGH confidence (likely) leaks
 */
export function getDrillsForLeaks(leaks: PossibleLeak[]): DrillRecommendation[] {
  const drillSet = new Map<string, DrillRecommendation>();

  for (const leak of leaks) {
    // Only prescribe drills for 'likely' leaks (high confidence)
    if (leak.probability !== 'likely') {
      continue;
    }

    const drillTags = LEAK_DRILL_TAGS[leak.leakType] || [];

    for (const tag of drillTags) {
      const drill = DRILL_MAPPINGS[tag];
      if (drill && !drillSet.has(drill.drill_id)) {
        drillSet.set(drill.drill_id, drill);
      }
    }
  }

  // Sort by priority
  const drills = Array.from(drillSet.values());
  drills.sort((a, b) => a.priority - b.priority);

  // Return top 3 drills max
  return drills.slice(0, 3);
}

/**
 * Get single best drill for a specific leak
 */
export function getBestDrillForLeak(leakType: string): DrillRecommendation | null {
  const drillTags = LEAK_DRILL_TAGS[leakType] || [];
  if (drillTags.length === 0) return null;

  // Return the first (highest priority) drill
  const drill = DRILL_MAPPINGS[drillTags[0]];
  return drill || null;
}

/**
 * Get all drills in a category
 */
export function getDrillsByCategory(
  category: 'release' | 'timing' | 'path' | 'upstream'
): DrillRecommendation[] {
  const categoryLeaks: Record<string, string[]> = {
    release: ['early_release', 'suboptimal_release', 'release_efficiency'],
    timing: ['inconsistent_load', 'timing_variance'],
    path: ['variable_path', 'path_variance', 'scattered_direction'],
    upstream: ['upstream_limitation', 'low_rotation'],
  };

  const leakTypes = categoryLeaks[category] || [];
  const drillSet = new Map<string, DrillRecommendation>();

  for (const leakType of leakTypes) {
    const drillTags = LEAK_DRILL_TAGS[leakType] || [];
    for (const tag of drillTags) {
      const drill = DRILL_MAPPINGS[tag];
      if (drill && !drillSet.has(drill.drill_id)) {
        drillSet.set(drill.drill_id, drill);
      }
    }
  }

  return Array.from(drillSet.values()).sort((a, b) => a.priority - b.priority);
}

/**
 * Get drill by ID
 */
export function getDrillById(drillId: string): DrillRecommendation | null {
  return (
    Object.values(DRILL_MAPPINGS).find((drill) => drill.drill_id === drillId) ||
    null
  );
}

/**
 * Get all available drills
 */
export function getAllDrills(): DrillRecommendation[] {
  return Object.values(DRILL_MAPPINGS);
}
