// ============================================================================
// BAT SPEED BENCHMARKS
// Age/size-based expected bat speed for Kinetic Potential calculation
// ============================================================================

export interface PlayerProfile {
  age_group: string;
  height_inches?: number;
  weight_lbs?: number;
  level?: 'youth' | 'high_school' | 'college' | 'pro' | 'adult';
}

export interface BatSpeedRange {
  min: number;
  median: number;
  max: number;
}

// ============================================================================
// EXPECTED BAT SPEED BY AGE GROUP
// ============================================================================

export const EXPECTED_BAT_SPEED: Record<string, BatSpeedRange> = {
  '8u': { min: 28, median: 35, max: 42 },
  '9u': { min: 32, median: 40, max: 48 },
  '10u': { min: 35, median: 45, max: 55 },
  '11u': { min: 38, median: 48, max: 58 },
  '12u': { min: 40, median: 52, max: 62 },
  '13u': { min: 45, median: 56, max: 68 },
  '14u': { min: 50, median: 60, max: 72 },
  '15u': { min: 52, median: 64, max: 76 },
  '16u': { min: 55, median: 68, max: 80 },
  'hs': { min: 55, median: 68, max: 82 },
  'high_school': { min: 55, median: 68, max: 82 },
  'college': { min: 65, median: 76, max: 90 },
  'pro': { min: 70, median: 82, max: 95 },
  'mlb': { min: 72, median: 85, max: 98 },
  'adult': { min: 55, median: 68, max: 80 },
};

// ============================================================================
// EXPECTED HAND-TO-BAT RATIO BY LEVEL
// ============================================================================

export const EXPECTED_RATIO: Record<string, BatSpeedRange> = {
  'youth': { min: 1.10, median: 1.20, max: 1.30 },
  '12u': { min: 1.12, median: 1.22, max: 1.32 },
  '14u': { min: 1.15, median: 1.25, max: 1.35 },
  'high_school': { min: 1.18, median: 1.26, max: 1.36 },
  'college': { min: 1.20, median: 1.28, max: 1.40 },
  'pro': { min: 1.22, median: 1.30, max: 1.42 },
  'elite': { min: 1.25, median: 1.32, max: 1.45 },
};

// ============================================================================
// FUNCTIONS
// ============================================================================

/**
 * Get expected bat speed for a player profile
 * Adjusts baseline for body size if available
 */
export function getExpectedBatSpeed(profile: PlayerProfile): number {
  const ageGroup = normalizeAgeGroup(profile.age_group);
  const baselines = EXPECTED_BAT_SPEED[ageGroup] || EXPECTED_BAT_SPEED['adult'];

  // Adjust for body size if available
  if (profile.height_inches && profile.weight_lbs) {
    const sizeMultiplier = calculateSizeMultiplier(profile.height_inches, profile.weight_lbs);
    return Math.round(baselines.median * sizeMultiplier * 10) / 10;
  }

  return baselines.median;
}

/**
 * Get expected bat speed range for an age group
 */
export function getExpectedBatSpeedRange(ageGroup: string): BatSpeedRange {
  const normalized = normalizeAgeGroup(ageGroup);
  return EXPECTED_BAT_SPEED[normalized] || EXPECTED_BAT_SPEED['adult'];
}

/**
 * Get expected hand-to-bat ratio for a level
 */
export function getExpectedRatio(level: string): BatSpeedRange {
  const normalized = normalizeLevel(level);
  return EXPECTED_RATIO[normalized] || EXPECTED_RATIO['high_school'];
}

/**
 * Calculate how much of their potential a player is realizing
 * Returns 0-100 (percentage of expected max they're hitting)
 */
export function calculatePotentialRealization(
  currentBatSpeed: number,
  profile: PlayerProfile
): number {
  const expected = getExpectedBatSpeedRange(profile.age_group);

  // If they're above expected max, they're at 100%+
  if (currentBatSpeed >= expected.max) {
    return 100;
  }

  // Scale from min (0%) to max (100%)
  const range = expected.max - expected.min;
  const position = currentBatSpeed - expected.min;

  return Math.max(0, Math.min(100, (position / range) * 100));
}

/**
 * Calculate size multiplier based on height and weight
 * 5'10" 170lb = 1.0 baseline
 */
function calculateSizeMultiplier(height: number, weight: number): number {
  // Larger players have higher potential
  // 70 inches = 5'10", 170 lbs = baseline
  const heightFactor = height / 70;
  const weightFactor = weight / 170;

  // Height matters more than weight for bat speed potential
  return heightFactor * 0.4 + weightFactor * 0.6;
}

/**
 * Normalize age group string to standard format
 */
function normalizeAgeGroup(ageGroup: string): string {
  const lower = ageGroup.toLowerCase().trim();

  // Direct matches
  if (EXPECTED_BAT_SPEED[lower]) {
    return lower;
  }

  // Parse "XU" format
  const uMatch = lower.match(/(\d+)\s*u/);
  if (uMatch) {
    return `${uMatch[1]}u`;
  }

  // Parse age ranges
  if (lower.includes('high') || lower.includes('hs') || lower.match(/15|16|17|18/)) {
    return 'high_school';
  }
  if (lower.includes('college') || lower.includes('uni')) {
    return 'college';
  }
  if (lower.includes('pro') || lower.includes('mlb') || lower.includes('minor')) {
    return 'pro';
  }

  // Default
  return 'adult';
}

/**
 * Normalize level string to standard format
 */
function normalizeLevel(level: string): string {
  const lower = level.toLowerCase().trim();

  if (lower.includes('youth') || lower.includes('10u') || lower.includes('8u')) {
    return 'youth';
  }
  if (lower.includes('12u') || lower.includes('11u')) {
    return '12u';
  }
  if (lower.includes('14u') || lower.includes('13u')) {
    return '14u';
  }
  if (lower.includes('high') || lower.includes('hs') || lower.includes('15u') || lower.includes('16u')) {
    return 'high_school';
  }
  if (lower.includes('college') || lower.includes('uni')) {
    return 'college';
  }
  if (lower.includes('pro') || lower.includes('mlb')) {
    return 'pro';
  }
  if (lower.includes('elite')) {
    return 'elite';
  }

  return 'high_school';
}

/**
 * Get target bat speed for kinetic potential calculation
 * This is the speed they "should" be hitting based on their profile
 */
export function getTargetBatSpeed(
  profile: PlayerProfile,
  currentRatio: number
): {
  targetSpeed: number;
  speedGap: number;
  ratioGap: number;
  totalPotential: number;
} {
  const expectedSpeed = getExpectedBatSpeed(profile);
  const expectedRatioRange = getExpectedRatio(profile.level || 'high_school');

  // If their ratio is low, that's bat speed hiding
  const ratioTarget = expectedRatioRange.median;
  const ratioGap = Math.max(0, ratioTarget - currentRatio);

  // Speed gap is distance from expected
  const currentSpeed = expectedSpeed; // We'll use facts.batSpeedMax in actual use
  const speedGap = Math.max(0, expectedSpeed - currentSpeed);

  // Ratio gap translates to mph unlock
  // If ratio is 1.15 but should be 1.28, that's ~10% more bat speed potential
  const ratioUnlock = ratioGap * 30; // Roughly 3 mph per 0.1 ratio improvement

  return {
    targetSpeed: expectedSpeed,
    speedGap,
    ratioGap: Math.round(ratioGap * 100) / 100,
    totalPotential: Math.round((speedGap + ratioUnlock) * 10) / 10,
  };
}
