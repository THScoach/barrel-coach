// ============================================================================
// ANALYSIS SAVE FUNCTIONS
// Robust error handling for saving Kwon analysis to database
// ============================================================================

import { createClient } from '@supabase/supabase-js';
import type { KwonAnalysis } from './types';
import type { KineticFingerprint } from './fingerprint';

// Initialize Supabase client (server-side)
const getSupabase = () =>
  createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

// ============================================================================
// TYPES
// ============================================================================

export interface SaveAnalysisResult {
  success: boolean;
  analysisId?: string;
  error?: string;
  errorCode?: string;
}

export interface SaveFingerprintResult {
  success: boolean;
  fingerprintId?: string;
  error?: string;
}

// ============================================================================
// SAVE KWON ANALYSIS
// ============================================================================

/**
 * Save Kwon analysis to database with full error handling
 */
export async function saveKwonAnalysis(
  playerId: string,
  sessionId: string,
  analysis: KwonAnalysis
): Promise<SaveAnalysisResult> {
  const supabase = getSupabase();

  try {
    // Validate required fields
    if (!playerId || !sessionId || !analysis) {
      return {
        success: false,
        error: 'Missing required fields: playerId, sessionId, or analysis',
        errorCode: 'VALIDATION_ERROR',
      };
    }

    // Prepare record for insertion
    const record = {
      player_id: playerId,
      session_id: sessionId,
      analysis_date: analysis.analysisDate.toISOString(),
      swings_analyzed: analysis.swingsAnalyzed,
      data_quality: analysis.dataQuality,
      motor_profile: analysis.motorProfile,

      // Store complex objects as JSONB
      sensor_facts: analysis.sensorFacts,
      release_prediction: analysis.releasePrediction,
      timing_prediction: analysis.timingPrediction,
      upstream_prediction: analysis.upstreamPrediction,
      kinetic_potential: analysis.kineticPotential,
      possible_leaks: analysis.possibleLeaks,
      four_b_scores: analysis.fourBScores,

      // Focus areas
      priority_focus: analysis.priorityFocus,
      secondary_focus: analysis.secondaryFocus,
    };

    // Insert analysis
    const { data: insertData, error: insertError } = await supabase
      .from('kwon_analyses')
      .insert(record)
      .select('id')
      .single();

    if (insertError) {
      console.error(`[Kwon Analysis] Insert failed for ${playerId}:`, insertError);
      return {
        success: false,
        error: insertError.message,
        errorCode: insertError.code,
      };
    }

    const analysisId = insertData?.id;

    // Update player's latest analysis reference
    const { error: updateError } = await supabase
      .from('players')
      .update({
        latest_analysis_id: analysisId,
        kinetic_potential: analysis.kineticPotential.totalUnlock,
        updated_at: new Date().toISOString(),
      })
      .eq('id', playerId);

    if (updateError) {
      // Non-fatal - analysis saved, just player update failed
      console.warn(`[Kwon Analysis] Player update failed for ${playerId}:`, updateError);
    }

    return {
      success: true,
      analysisId,
    };
  } catch (error) {
    console.error(`[Kwon Analysis] Save failed for ${playerId}:`, error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      errorCode: 'EXCEPTION',
    };
  }
}

// ============================================================================
// SAVE KINETIC FINGERPRINT
// ============================================================================

/**
 * Save or update kinetic fingerprint for a player
 */
export async function saveKineticFingerprint(
  playerId: string,
  fingerprint: KineticFingerprint
): Promise<SaveFingerprintResult> {
  const supabase = getSupabase();

  try {
    // Prepare record
    const record = {
      player_id: playerId,
      intent_map: {
        horizontalMean: fingerprint.horizontal.mean,
        horizontalStdDev: fingerprint.horizontal.std,
        verticalMean: fingerprint.vertical.mean,
        verticalStdDev: fingerprint.vertical.std,
        depthIndex: fingerprint.depth.mean,
        depthConsistency: 100 - fingerprint.tempo.variance_pct,
      },
      timing_signature: {
        triggerToImpactMs: fingerprint.tempo.avg_trigger_to_impact,
        timingVariance: fingerprint.tempo.variance_pct / 100,
        tempoCategory: fingerprint.tempo.category,
      },
      pattern_metrics: {
        tightness: fingerprint.tightness,
        pullBias: fingerprint.pull_bias,
        zoneBias: fingerprint.zone_bias,
        comfortZone: fingerprint.comfort_zone,
      },
      swing_count: fingerprint.swing_count,
      last_updated: fingerprint.calculated_at,
    };

    // Upsert fingerprint (one per player)
    const { data, error } = await supabase
      .from('kinetic_fingerprints')
      .upsert(record, {
        onConflict: 'player_id',
      })
      .select('id')
      .single();

    if (error) {
      console.error(`[Fingerprint] Save failed for ${playerId}:`, error);
      return {
        success: false,
        error: error.message,
      };
    }

    // Save to history
    await supabase.from('kinetic_fingerprint_history').insert({
      player_id: playerId,
      fingerprint_snapshot: fingerprint,
      swing_count: fingerprint.swing_count,
      recorded_at: fingerprint.calculated_at,
    });

    return {
      success: true,
      fingerprintId: data?.id,
    };
  } catch (error) {
    console.error(`[Fingerprint] Save failed for ${playerId}:`, error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

// ============================================================================
// GET LATEST ANALYSIS
// ============================================================================

/**
 * Get the latest analysis for a player
 */
export async function getLatestAnalysis(
  playerId: string
): Promise<KwonAnalysis | null> {
  const supabase = getSupabase();

  try {
    const { data, error } = await supabase
      .from('kwon_analyses')
      .select('*')
      .eq('player_id', playerId)
      .order('analysis_date', { ascending: false })
      .limit(1)
      .single();

    if (error || !data) {
      return null;
    }

    // Convert back to KwonAnalysis type
    return {
      sessionId: data.session_id,
      playerId: data.player_id,
      analysisDate: new Date(data.analysis_date),
      sensorFacts: data.sensor_facts,
      releasePrediction: data.release_prediction,
      timingPrediction: data.timing_prediction,
      upstreamPrediction: data.upstream_prediction,
      kineticPotential: data.kinetic_potential,
      possibleLeaks: data.possible_leaks,
      fourBScores: data.four_b_scores,
      motorProfile: data.motor_profile,
      priorityFocus: data.priority_focus,
      secondaryFocus: data.secondary_focus,
      swingsAnalyzed: data.swings_analyzed,
      dataQuality: data.data_quality,
    };
  } catch (error) {
    console.error(`[Kwon Analysis] Get failed for ${playerId}:`, error);
    return null;
  }
}

// ============================================================================
// GET LATEST FINGERPRINT
// ============================================================================

/**
 * Get the latest fingerprint for a player
 */
export async function getLatestFingerprint(
  playerId: string
): Promise<KineticFingerprint | null> {
  const supabase = getSupabase();

  try {
    const { data, error } = await supabase
      .from('kinetic_fingerprints')
      .select('*')
      .eq('player_id', playerId)
      .single();

    if (error || !data) {
      return null;
    }

    // Convert back to KineticFingerprint type
    return {
      player_id: data.player_id,
      period_days: 7, // Default
      swing_count: data.swing_count,
      horizontal: {
        mean: data.intent_map.horizontalMean,
        std: data.intent_map.horizontalStdDev,
      },
      vertical: {
        mean: data.intent_map.verticalMean,
        std: data.intent_map.verticalStdDev,
      },
      depth: {
        mean: data.intent_map.depthIndex,
        std: 0, // Not stored separately
      },
      scatter_score: 0, // Recalculate if needed
      tightness: data.pattern_metrics.tightness,
      tempo: {
        avg_trigger_to_impact: data.timing_signature.triggerToImpactMs,
        variance_pct: data.timing_signature.timingVariance * 100,
        category: data.timing_signature.tempoCategory,
      },
      pull_bias: data.pattern_metrics.pullBias,
      zone_bias: data.pattern_metrics.zoneBias,
      comfort_zone: data.pattern_metrics.comfortZone,
      heatmap: [], // Not stored in main table
      scatter_change: 0,
      calculated_at: data.last_updated,
      period_start: data.last_updated,
      period_end: data.last_updated,
    };
  } catch (error) {
    console.error(`[Fingerprint] Get failed for ${playerId}:`, error);
    return null;
  }
}

// ============================================================================
// ANALYSIS COMPARISON
// ============================================================================

export interface AnalysisComparison {
  bat_speed_change: number;
  ratio_change: number;
  timing_variance_change: number;
  potential_change: number;
  period_days: number;
}

/**
 * Compare current analysis with historical analysis
 */
export async function compareAnalysisOverTime(
  playerId: string,
  periodDays: number = 30
): Promise<AnalysisComparison | null> {
  const supabase = getSupabase();

  try {
    // Get current analysis
    const { data: current } = await supabase
      .from('kwon_analyses')
      .select('*')
      .eq('player_id', playerId)
      .order('analysis_date', { ascending: false })
      .limit(1)
      .single();

    if (!current) return null;

    // Get previous analysis from X days ago
    const cutoffDate = new Date(Date.now() - periodDays * 24 * 60 * 60 * 1000);
    const { data: previous } = await supabase
      .from('kwon_analyses')
      .select('*')
      .eq('player_id', playerId)
      .lt('analysis_date', cutoffDate.toISOString())
      .order('analysis_date', { ascending: false })
      .limit(1)
      .single();

    if (!previous) return null;

    return {
      bat_speed_change:
        current.sensor_facts.batSpeedMax - previous.sensor_facts.batSpeedMax,
      ratio_change:
        current.sensor_facts.handToBatRatio -
        previous.sensor_facts.handToBatRatio,
      timing_variance_change:
        current.sensor_facts.timingCV - previous.sensor_facts.timingCV,
      potential_change:
        current.kinetic_potential.totalUnlock -
        previous.kinetic_potential.totalUnlock,
      period_days: periodDays,
    };
  } catch (error) {
    console.error(`[Analysis Comparison] Failed for ${playerId}:`, error);
    return null;
  }
}
