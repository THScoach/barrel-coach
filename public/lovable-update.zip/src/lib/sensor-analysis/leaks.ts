// ============================================================================
// POSSIBLE LEAKS DETECTION
// Identify potential energy leaks with probability levels
// "We don't tell them what's wrong, we show what's hiding"
// ============================================================================

import type { SensorFacts, PossibleLeak, LeakProbability, PopulationBaseline } from './types';
import { calculatePercentile } from './extract-facts';

/**
 * Identify possible energy leaks from sensor data
 * Each leak includes probability level and how to confirm
 */
export function identifyPossibleLeaks(
  facts: SensorFacts,
  baseline: PopulationBaseline
): PossibleLeak[] {
  const leaks: PossibleLeak[] = [];

  // ============================================================================
  // RELEASE LEAKS (HIGH confidence detection)
  // ============================================================================

  // Early release / bat dump
  if (facts.handToBatRatio < 1.18) {
    leaks.push({
      leakType: 'early_release',
      category: 'release',
      description: 'Bat is releasing early, losing stored energy',
      probability: 'likely',
      evidence: `Hand-to-bat ratio of ${facts.handToBatRatio.toFixed(2)} is below optimal range (1.20-1.30). ` +
        `This indicates the bat is "dumping" before the hands finish accelerating.`,
      potentialGain: estimateReleaseGain(facts.handToBatRatio, facts.handSpeedMean),
      howToConfirm: 'Video analysis of wrist/barrel connection through contact zone',
    });
  } else if (facts.handToBatRatio < 1.22) {
    leaks.push({
      leakType: 'suboptimal_release',
      category: 'release',
      description: 'Release timing could be sharper',
      probability: 'possible',
      evidence: `Hand-to-bat ratio of ${facts.handToBatRatio.toFixed(2)} is functional but below elite level.`,
      potentialGain: estimateReleaseGain(facts.handToBatRatio, facts.handSpeedMean),
      howToConfirm: 'High-speed video of bat lag angle at contact',
    });
  }

  // ============================================================================
  // TIMING LEAKS (MEDIUM confidence detection)
  // ============================================================================

  // Inconsistent load timing
  if (facts.timingCV > 0.12) {
    leaks.push({
      leakType: 'inconsistent_load',
      category: 'timing',
      description: 'Load-to-launch timing is inconsistent, wasting energy',
      probability: 'likely',
      evidence: `Timing CV of ${(facts.timingCV * 100).toFixed(1)}% is high. ` +
        `Consistent hitters are typically under 6%. This variance costs bat speed.`,
      potentialGain: Math.min(4, (facts.timingCV - 0.05) * 40),
      howToConfirm: 'Video analysis of load timing relative to pitch recognition',
    });
  } else if (facts.timingCV > 0.08) {
    leaks.push({
      leakType: 'timing_variance',
      category: 'timing',
      description: 'Timing could be tightened up',
      probability: 'possible',
      evidence: `Timing CV of ${(facts.timingCV * 100).toFixed(1)}% suggests some inconsistency ` +
        `in the load-to-swing sequence.`,
      potentialGain: Math.min(2, (facts.timingCV - 0.05) * 30),
      howToConfirm: 'Rhythm drills and tempo work to tighten pattern',
    });
  }

  // ============================================================================
  // PATH LEAKS (MEDIUM confidence detection)
  // ============================================================================

  // Inconsistent attack angle
  if (facts.attackAngleStdDev > 10) {
    leaks.push({
      leakType: 'variable_path',
      category: 'path',
      description: 'Bat path is highly variable, indicating inconsistent swing plane',
      probability: 'likely',
      evidence: `Attack angle std dev of ${facts.attackAngleStdDev.toFixed(1)}° is high. ` +
        `This often indicates a disconnected swing path.`,
      potentialGain: 2.0,
      howToConfirm: 'Video to see if path variance is intentional adjustment or mechanical issue',
    });
  } else if (facts.attackAngleStdDev > 6) {
    leaks.push({
      leakType: 'path_variance',
      category: 'path',
      description: 'Some variance in bat path',
      probability: 'possible',
      evidence: `Attack angle std dev of ${facts.attackAngleStdDev.toFixed(1)}° suggests ` +
        `room for tighter path control.`,
      potentialGain: 1.0,
      howToConfirm: 'Check if variance correlates with pitch location adjustment',
    });
  }

  // Direction inconsistency (pull vs oppo)
  if (facts.attackDirectionStdDev > 15) {
    leaks.push({
      leakType: 'scattered_direction',
      category: 'path',
      description: 'Attack direction is scattered, may indicate timing or connection issues',
      probability: 'possible',
      evidence: `Attack direction std dev of ${facts.attackDirectionStdDev.toFixed(1)}° ` +
        `shows a very wide spray pattern.`,
      potentialGain: 1.5,
      howToConfirm: 'Determine if this is adaptive or a symptom of inconsistency',
    });
  }

  // ============================================================================
  // UPSTREAM LEAKS (LOW confidence - speculative)
  // ============================================================================

  // Low hand speed relative to population
  const handSpeedPercentile = calculatePercentile(
    facts.handSpeedMean,
    baseline.handSpeed.p10,
    baseline.handSpeed.p50,
    baseline.handSpeed.p90
  );

  const batSpeedPercentile = calculatePercentile(
    facts.batSpeedMean,
    baseline.batSpeed.p10,
    baseline.batSpeed.p50,
    baseline.batSpeed.p90
  );

  // If bat speed percentile is much lower than hand speed percentile
  // This suggests good upstream but release leak
  if (batSpeedPercentile < handSpeedPercentile - 20) {
    leaks.push({
      leakType: 'release_efficiency',
      category: 'release',
      description: 'Hands are fast but bat speed is lagging - energy not transferring',
      probability: 'likely',
      evidence: `Hand speed is ${handSpeedPercentile.toFixed(0)}th percentile but ` +
        `bat speed is only ${batSpeedPercentile.toFixed(0)}th percentile. ` +
        `Energy is getting lost in the release.`,
      potentialGain: estimateReleaseGain(facts.handToBatRatio, facts.handSpeedMean),
      howToConfirm: 'Focus on barrel lag and whip drills',
    });
  }

  // If hand speed is low but ratio is good, upstream issue
  if (handSpeedPercentile < 30 && facts.handToBatRatio >= 1.25) {
    leaks.push({
      leakType: 'upstream_limitation',
      category: 'upstream',
      description: 'Release is efficient but hands are slow - upstream energy production may be limited',
      probability: 'speculative',
      evidence: `Good hand-to-bat ratio (${facts.handToBatRatio.toFixed(2)}) but ` +
        `hand speed is only ${handSpeedPercentile.toFixed(0)}th percentile. ` +
        `This suggests the swing mechanics are efficient but force production is limited.`,
      potentialGain: 3.0,
      howToConfirm: 'Video analysis of hip drive, ground force utilization, and kinetic chain sequencing',
    });
  }

  // Check for potential sequencing issues (speculative without video)
  if (facts.rotationalAccelerationMean !== undefined && facts.rotationalAccelerationMean < 15000) {
    leaks.push({
      leakType: 'low_rotation',
      category: 'upstream',
      description: 'Rotational acceleration is lower than expected',
      probability: 'speculative',
      evidence: `Rotational acceleration of ${facts.rotationalAccelerationMean.toFixed(0)} deg/s² ` +
        `may indicate limited hip/torso separation.`,
      potentialGain: 2.5,
      howToConfirm: 'Video to assess hip-shoulder separation at toe touch',
    });
  }

  // Sort by potential gain (highest first)
  leaks.sort((a, b) => b.potentialGain - a.potentialGain);

  return leaks;
}

/**
 * Estimate mph gain from improving release
 */
function estimateReleaseGain(currentRatio: number, handSpeed: number): number {
  const targetRatio = 1.28;
  if (currentRatio >= targetRatio) return 0;

  const currentBatSpeed = handSpeed * currentRatio;
  const potentialBatSpeed = handSpeed * targetRatio;
  return Math.round((potentialBatSpeed - currentBatSpeed) * 10) / 10;
}

/**
 * Get the highest-probability leak
 */
export function getPrimaryLeak(leaks: PossibleLeak[]): PossibleLeak | null {
  // Priority: likely > possible > speculative, then by potential gain
  const likelyLeaks = leaks.filter(l => l.probability === 'likely');
  if (likelyLeaks.length > 0) {
    return likelyLeaks.reduce((a, b) => a.potentialGain > b.potentialGain ? a : b);
  }

  const possibleLeaks = leaks.filter(l => l.probability === 'possible');
  if (possibleLeaks.length > 0) {
    return possibleLeaks.reduce((a, b) => a.potentialGain > b.potentialGain ? a : b);
  }

  const speculativeLeaks = leaks.filter(l => l.probability === 'speculative');
  if (speculativeLeaks.length > 0) {
    return speculativeLeaks.reduce((a, b) => a.potentialGain > b.potentialGain ? a : b);
  }

  return null;
}

/**
 * Get total potential gain from all identified leaks
 * Note: These don't stack 1:1, so we apply diminishing returns
 */
export function getTotalPotentialGain(leaks: PossibleLeak[]): number {
  if (leaks.length === 0) return 0;

  // Sort by gain
  const sortedGains = leaks.map(l => l.potentialGain).sort((a, b) => b - a);

  // First leak: full value
  // Second leak: 50% value
  // Third+: 25% value
  let total = 0;
  sortedGains.forEach((gain, index) => {
    if (index === 0) total += gain;
    else if (index === 1) total += gain * 0.5;
    else total += gain * 0.25;
  });

  return Math.round(total * 10) / 10;
}
