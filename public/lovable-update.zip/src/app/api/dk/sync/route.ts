// ============================================================================
// DIAMOND KINETICS SYNC ENDPOINT
// POST /api/dk/sync - Receive and normalize swing data from DK sensor
// ============================================================================

import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { normalizeDKSwingBatch } from '@/lib/integrations/diamond-kinetics/normalizer';
import type { SyncResponse, CanonicalSwing } from '@/lib/integrations/diamond-kinetics/types';

// Initialize Supabase client
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(request: NextRequest): Promise<NextResponse<SyncResponse | { error: string; ingest_id?: string }>> {
  const playerId = request.headers.get('x-player-id');
  if (!playerId) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // FIX #4: Generate ingest_id for debugging batch failures
  const ingestId = `ingest_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

  try {
    const body = await request.json();
    const { sessionId, swings: dkSwings, dk_sdk_version } = body;

    console.log(`[DK Sync] ${ingestId} - Received ${dkSwings?.length || 0} swings for session ${sessionId}`);

    // Validate session ownership
    const { data: session, error: sessionError } = await supabase
      .from('sensor_sessions')
      .select('id')
      .eq('id', sessionId)
      .eq('player_id', playerId)
      .single();

    if (sessionError || !session) {
      console.log(`[DK Sync] ${ingestId} - Invalid session`);
      return NextResponse.json({ error: 'Invalid session' }, { status: 400 });
    }

    // Normalize all swings
    const { valid, invalid, warnings } = normalizeDKSwingBatch(
      dkSwings,
      sessionId,
      dk_sdk_version
    );

    // Log invalid for debugging
    if (invalid.length > 0) {
      console.log(
        `[DK Sync] ${ingestId} - Rejected ${invalid.length} swings:`,
        invalid.map((s) => ({
          number: s.swing_number,
          reason: s.invalid_reason,
          bat_speed: s.bat_speed_mph,
        }))
      );
    }

    // Log warnings
    if (warnings.length > 0) {
      console.log(
        `[DK Sync] ${ingestId} - Warnings on ${warnings.length} swings:`,
        warnings.map((s) => ({
          number: s.swing_number,
          warnings: s.warnings,
        }))
      );
    }

    // TWEAK #6: Batch insert with upsert (handles duplicates)
    const insertData = valid.map((swing) => ({
      player_id: playerId,
      session_id: sessionId,
      dk_swing_id: swing.dk_swing_id,
      occurred_at: swing.occurred_at,
      swing_number: swing.swing_number,

      bat_speed_mph: swing.bat_speed_mph,
      hand_speed_mph: swing.hand_speed_mph,
      hand_to_bat_ratio: swing.hand_to_bat_ratio,
      trigger_to_impact_ms: swing.trigger_to_impact_ms,
      attack_angle_deg: swing.attack_angle_deg,
      attack_direction_deg: swing.attack_direction_deg,
      swing_plane_tilt_deg: swing.swing_plane_tilt_deg,
      impact_location_x: swing.impact_location_x,
      impact_location_y: swing.impact_location_y,
      impact_location_z: swing.impact_location_z,
      applied_power: swing.applied_power,
      max_acceleration: swing.max_acceleration,

      is_valid: swing.is_valid,
      invalid_reason: swing.invalid_reason,
      warnings: swing.warnings,
      // FIX #6: Store occurred_at_raw inside raw_meta
      raw_dk_data: { data: swing.raw, meta: swing.raw_meta },
    }));

    let inserted = 0;
    let duplicates = 0;

    if (insertData.length > 0) {
      // Supabase batch insert - use upsert to handle duplicates gracefully
      const { data: insertResult, error: insertError } = await supabase
        .from('sensor_swings')
        .insert(insertData)
        .select('id');

      if (insertError) {
        // TWEAK #7: Handle various duplicate error formats
        if (isDuplicateError(insertError)) {
          console.log(`[DK Sync] ${ingestId} - Batch has duplicates, falling back to individual inserts`);
          const results = await insertWithFallback(insertData, playerId, ingestId);
          inserted = results.inserted;
          duplicates = results.duplicates;
        } else {
          console.error(`[DK Sync] ${ingestId} - Insert error:`, insertError);
          throw insertError;
        }
      } else {
        inserted = insertResult?.length || 0;
        duplicates = insertData.length - inserted;
      }
    }

    console.log(
      `[DK Sync] ${ingestId} - Complete: ${inserted} inserted, ${duplicates} duplicates, ${invalid.length} rejected`
    );

    // Update session aggregates
    await updateSessionAggregates(sessionId);

    // Check for baseline completion
    await checkBaselineCompletion(playerId, sessionId);

    // Check for PRs
    if (valid.length > 0) {
      await checkForPRs(playerId, valid);
    }

    return NextResponse.json({
      success: true,
      ingest_id: ingestId,
      processed: inserted,
      duplicates,
      rejected: invalid.length,
      warnings: warnings.length,
      total_received: dkSwings.length,
    });
  } catch (error) {
    console.error(`[DK Sync] ${ingestId} - Error:`, error);
    return NextResponse.json(
      { error: 'Failed to sync swing data', ingest_id: ingestId },
      { status: 500 }
    );
  }
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

// TWEAK #7: Handle multiple error formats
function isDuplicateError(error: unknown): boolean {
  if (!error || typeof error !== 'object') return false;

  const err = error as Record<string, unknown>;

  // Postgres
  if (err.code === '23505') return true;

  // Prisma
  if (err.code === 'P2002') return true;

  // Message fallback
  const message = String(err.message || '').toLowerCase();
  if (message.includes('duplicate key value')) return true;
  if (message.includes('unique constraint')) return true;

  return false;
}

// Fallback for when batch insert fails
async function insertWithFallback(
  data: Record<string, unknown>[],
  playerId: string,
  ingestId: string
): Promise<{ inserted: number; duplicates: number }> {
  let inserted = 0;
  let duplicates = 0;

  for (const row of data) {
    const { error } = await supabase.from('sensor_swings').insert(row);

    if (error) {
      if (isDuplicateError(error)) {
        duplicates++;
      } else {
        // FIX #4: Log non-duplicate failures with ingest_id
        console.error(
          `[DK Sync] ${ingestId} - Insert failed for swing ${row.swing_number}:`,
          error
        );
        throw error;
      }
    } else {
      inserted++;
    }
  }

  return { inserted, duplicates };
}

async function updateSessionAggregates(sessionId: string): Promise<void> {
  const { data: swings } = await supabase
    .from('sensor_swings')
    .select('bat_speed_mph, trigger_to_impact_ms, hand_to_bat_ratio')
    .eq('session_id', sessionId)
    .eq('is_valid', true);

  if (!swings || swings.length === 0) return;

  const batSpeeds = swings.map((s) => s.bat_speed_mph).filter(Boolean) as number[];
  const timings = swings.map((s) => s.trigger_to_impact_ms).filter(Boolean) as number[];
  const ratios = swings.map((s) => s.hand_to_bat_ratio).filter(Boolean) as number[];

  const avg = (arr: number[]) => arr.reduce((a, b) => a + b, 0) / arr.length;
  const std = (arr: number[]) => {
    const mean = avg(arr);
    return Math.sqrt(arr.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / arr.length);
  };

  await supabase
    .from('sensor_sessions')
    .update({
      total_swings: swings.length,
      avg_bat_speed: Math.round(avg(batSpeeds) * 10) / 10,
      max_bat_speed: Math.max(...batSpeeds),
      avg_hand_to_bat_ratio: ratios.length > 0 ? Math.round(avg(ratios) * 100) / 100 : null,
      timing_variance_pct:
        timings.length > 1 ? Math.round((std(timings) / avg(timings)) * 1000) / 10 : null,
      updated_at: new Date().toISOString(),
    })
    .eq('id', sessionId);
}

async function checkBaselineCompletion(playerId: string, sessionId: string): Promise<void> {
  const { data: player } = await supabase
    .from('players')
    .select('sensor_baseline_complete, email')
    .eq('id', playerId)
    .single();

  if (player?.sensor_baseline_complete) return;

  const { count: totalSwings } = await supabase
    .from('sensor_swings')
    .select('*', { count: 'exact', head: true })
    .eq('player_id', playerId)
    .eq('is_valid', true);

  if (totalSwings && totalSwings >= 10) {
    await supabase
      .from('players')
      .update({
        sensor_baseline_complete: true,
        sensor_baseline_date: new Date().toISOString(),
        sensor_baseline_session_id: sessionId,
      })
      .eq('id', playerId);

    // Trigger GHL webhook
    if (process.env.GHL_WEBHOOK_URL) {
      fetch(process.env.GHL_WEBHOOK_URL + '/baseline_complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: player?.email,
          player_id: playerId,
          swing_count: totalSwings,
        }),
      }).catch((err) => console.error('[GHL Webhook] Failed:', err));
    }
  }
}

async function checkForPRs(playerId: string, swings: CanonicalSwing[]): Promise<void> {
  const { data: player } = await supabase
    .from('players')
    .select('current_bat_speed')
    .eq('id', playerId)
    .single();

  const currentMax = player?.current_bat_speed || 0;
  const sessionMax = Math.max(...swings.map((s) => s.bat_speed_mph || 0));

  if (sessionMax > currentMax) {
    await supabase
      .from('players')
      .update({ current_bat_speed: sessionMax })
      .eq('id', playerId);

    // Award XP, auto-post, etc.
    console.log(`[PR] ${playerId} new max: ${sessionMax} (was ${currentMax})`);
  }
}
