// ============================================================================
// DIAMOND KINETICS NORMALIZER - UNIT TESTS
// ============================================================================

import { normalizeDKSwing, normalizeDKSwingBatch } from '../lib/integrations/diamond-kinetics/normalizer';

describe('DK Normalizer', () => {
  const baseOpts = { session_id: 'test-session-123' };

  // ✅ Field mapping tests
  describe('Field Mapping', () => {
    test('maps speedBarrelMax correctly', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 65.5 }, baseOpts);
      expect(swing.bat_speed_mph).toBe(65.5);
    });

    test('maps batSpeed as fallback', () => {
      const swing = normalizeDKSwing({ batSpeed: 70.2 }, baseOpts);
      expect(swing.bat_speed_mph).toBe(70.2);
    });

    test('maps nested metrics.speedBarrelMax', () => {
      const swing = normalizeDKSwing({ metrics: { speedBarrelMax: 68.0 } }, baseOpts);
      expect(swing.bat_speed_mph).toBe(68.0);
    });

    test('maps hand speed aliases', () => {
      const swing1 = normalizeDKSwing({ speedBarrelMax: 70, speedHandsMax: 55 }, baseOpts);
      expect(swing1.hand_speed_mph).toBe(55);

      const swing2 = normalizeDKSwing({ speedBarrelMax: 70, handSpeed: 52.3 }, baseOpts);
      expect(swing2.hand_speed_mph).toBe(52.3);
    });

    test('maps attack angle aliases', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 70, swingPlaneSteepnessAngle: 15.5 }, baseOpts);
      expect(swing.attack_angle_deg).toBe(15.5);
    });

    test('maps attack direction aliases', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 70, swingPlaneHeadingAngle: -8.2 }, baseOpts);
      expect(swing.attack_direction_deg).toBe(-8.2);
    });

    test('maps timing aliases', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 70, quicknessTriggerImpact: 180 }, baseOpts);
      expect(swing.trigger_to_impact_ms).toBe(180);
    });
  });

  // ✅ Timestamp parsing tests
  describe('Timestamp Parsing', () => {
    test('parses ISO string', () => {
      const swing = normalizeDKSwing(
        { speedBarrelMax: 65, timestamp: '2025-01-17T12:00:00.000Z' },
        baseOpts
      );
      expect(swing.occurred_at).toContain('2025-01-17');
    });

    test('parses epoch milliseconds', () => {
      const swing = normalizeDKSwing(
        { speedBarrelMax: 65, timestamp: 1705492800000 }, // 2024-01-17 12:00:00 UTC
        baseOpts
      );
      expect(swing.occurred_at).toContain('2024-01-17');
    });

    test('parses epoch seconds', () => {
      const swing = normalizeDKSwing(
        { speedBarrelMax: 65, timestamp: 1705492800 }, // 2024-01-17 12:00:00 UTC
        baseOpts
      );
      expect(swing.occurred_at).toContain('2024-01-17');
    });

    test('uses fallback when no timestamp', () => {
      const fallback = '2025-01-01T00:00:00.000Z';
      const swing = normalizeDKSwing({ speedBarrelMax: 65 }, { ...baseOpts, fallback_timestamp: fallback });
      expect(swing.occurred_at).toContain('2025-01-01');
    });
  });

  // ✅ Validation tests
  describe('Validation', () => {
    test('rejects bat speed 29.9', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 29.9 }, baseOpts);
      expect(swing.is_valid).toBe(false);
      expect(swing.invalid_reason).toBe('below_speed_threshold');
    });

    test('accepts bat speed 30.0', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 30.0 }, baseOpts);
      expect(swing.is_valid).toBe(true);
    });

    test('accepts bat speed 30.1', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 30.1 }, baseOpts);
      expect(swing.is_valid).toBe(true);
    });

    test('rejects missing bat speed', () => {
      const swing = normalizeDKSwing({ handSpeed: 50 }, baseOpts);
      expect(swing.is_valid).toBe(false);
      expect(swing.invalid_reason).toBe('missing_bat_speed');
    });

    test('warns on low hand speed but still valid', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 65, speedHandsMax: 18 }, baseOpts);
      expect(swing.is_valid).toBe(true);
      expect(swing.warnings).toContain('hand_speed_low');
    });

    test('accepts hand speed 20', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 65, speedHandsMax: 20 }, baseOpts);
      expect(swing.is_valid).toBe(true);
      expect(swing.warnings).not.toContain('hand_speed_low');
    });

    test('rejects timing too fast', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 65, quicknessTriggerImpact: 50 }, baseOpts);
      expect(swing.is_valid).toBe(false);
      expect(swing.invalid_reason).toBe('timing_too_fast');
    });

    test('accepts timing at 80ms boundary', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 65, quicknessTriggerImpact: 80 }, baseOpts);
      expect(swing.is_valid).toBe(true);
    });

    test('rejects timing too slow', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 65, quicknessTriggerImpact: 400 }, baseOpts);
      expect(swing.is_valid).toBe(false);
      expect(swing.invalid_reason).toBe('timing_too_slow');
    });

    test('accepts timing at 350ms boundary', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 65, quicknessTriggerImpact: 350 }, baseOpts);
      expect(swing.is_valid).toBe(true);
    });
  });

  // ✅ Rounding tests
  describe('Rounding for Dedupe', () => {
    test('rounds bat_speed_mph to 0.1', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 65.456 }, baseOpts);
      expect(swing.bat_speed_mph).toBe(65.5);
    });

    test('rounds hand_speed_mph to 0.1', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 70, speedHandsMax: 52.789 }, baseOpts);
      expect(swing.hand_speed_mph).toBe(52.8);
    });

    test('rounds hand_to_bat_ratio to 0.01', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 70, speedHandsMax: 55 }, baseOpts);
      // 70 / 55 = 1.2727... should round to 1.27
      expect(swing.hand_to_bat_ratio).toBe(1.27);
    });

    test('rounds occurred_at to 100ms', () => {
      const swing = normalizeDKSwing(
        { speedBarrelMax: 65, timestamp: '2025-01-17T12:00:00.123Z' },
        baseOpts
      );
      // Should round to .100 or .200
      expect(swing.occurred_at).toMatch(/\.\d00Z$/);
    });

    test('preserves original timestamp in occurred_at_raw', () => {
      const swing = normalizeDKSwing(
        { speedBarrelMax: 65, timestamp: '2025-01-17T12:00:00.123Z' },
        baseOpts
      );
      expect(swing.occurred_at_raw).toBe('2025-01-17T12:00:00.123Z');
    });
  });

  // ✅ Derived calculations
  describe('Derived Calculations', () => {
    test('calculates hand_to_bat_ratio correctly', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 78, speedHandsMax: 60 }, baseOpts);
      // 78 / 60 = 1.30
      expect(swing.hand_to_bat_ratio).toBe(1.3);
    });

    test('returns null ratio when hand speed is missing', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 70 }, baseOpts);
      expect(swing.hand_to_bat_ratio).toBeNull();
    });

    test('returns null ratio when hand speed is zero', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 70, speedHandsMax: 0 }, baseOpts);
      expect(swing.hand_to_bat_ratio).toBeNull();
    });
  });

  // ✅ Batch tests
  describe('Batch Processing', () => {
    test('separates valid and invalid', () => {
      const swings = [
        { speedBarrelMax: 65 }, // valid
        { speedBarrelMax: 25 }, // invalid
        { speedBarrelMax: 70 }, // valid
      ];
      const result = normalizeDKSwingBatch(swings, 'test-session');
      expect(result.valid.length).toBe(2);
      expect(result.invalid.length).toBe(1);
    });

    test('assigns swing numbers', () => {
      const swings = [{ speedBarrelMax: 65 }, { speedBarrelMax: 70 }];
      const result = normalizeDKSwingBatch(swings, 'test-session');
      expect(result.valid[0].swing_number).toBe(1);
      expect(result.valid[1].swing_number).toBe(2);
    });

    test('tracks warnings separately', () => {
      const swings = [
        { speedBarrelMax: 65 }, // valid, no warning
        { speedBarrelMax: 70, speedHandsMax: 15 }, // valid with warning
        { speedBarrelMax: 75, speedHandsMax: 60 }, // valid, no warning
      ];
      const result = normalizeDKSwingBatch(swings, 'test-session');
      expect(result.valid.length).toBe(3);
      expect(result.warnings.length).toBe(1);
      expect(result.warnings[0].swing_number).toBe(2);
    });

    test('handles empty batch', () => {
      const result = normalizeDKSwingBatch([], 'test-session');
      expect(result.valid.length).toBe(0);
      expect(result.invalid.length).toBe(0);
      expect(result.warnings.length).toBe(0);
    });
  });

  // ✅ Raw meta tests
  describe('Raw Meta', () => {
    test('includes normalizer version', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 65 }, baseOpts);
      expect(swing.raw_meta.normalizer_version).toBe('1.0.0');
    });

    test('includes received_at timestamp', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 65 }, baseOpts);
      expect(swing.raw_meta.received_at).toBeDefined();
      expect(new Date(swing.raw_meta.received_at).getTime()).not.toBeNaN();
    });

    test('stores dk_sdk_version if provided', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 65 }, {
        ...baseOpts,
        dk_sdk_version: '6.2.1',
      });
      expect(swing.raw_meta.dk_sdk_version).toBe('6.2.1');
    });

    test('dk_sdk_version is null if not provided', () => {
      const swing = normalizeDKSwing({ speedBarrelMax: 65 }, baseOpts);
      expect(swing.raw_meta.dk_sdk_version).toBeNull();
    });

    test('preserves original raw payload', () => {
      const original = { speedBarrelMax: 65, customField: 'test' };
      const swing = normalizeDKSwing(original, baseOpts);
      expect(swing.raw).toEqual(original);
    });
  });

  // ✅ Edge cases
  describe('Edge Cases', () => {
    test('handles null input', () => {
      const swing = normalizeDKSwing(null, baseOpts);
      expect(swing.is_valid).toBe(false);
      expect(swing.invalid_reason).toBe('missing_bat_speed');
    });

    test('handles undefined input', () => {
      const swing = normalizeDKSwing(undefined, baseOpts);
      expect(swing.is_valid).toBe(false);
      expect(swing.invalid_reason).toBe('missing_bat_speed');
    });

    test('handles empty object', () => {
      const swing = normalizeDKSwing({}, baseOpts);
      expect(swing.is_valid).toBe(false);
      expect(swing.invalid_reason).toBe('missing_bat_speed');
    });

    test('handles deeply nested metrics', () => {
      const swing = normalizeDKSwing(
        { metrics: { speedBarrelMax: 72, speedHandsMax: 56 } },
        baseOpts
      );
      expect(swing.bat_speed_mph).toBe(72);
      expect(swing.hand_speed_mph).toBe(56);
    });
  });
});
