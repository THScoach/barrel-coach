# Partner Email Campaign
## For [Buddy's Name] List — 30% Commission

---

## THE DEAL

| Item | Amount |
|------|--------|
| Assessment Price | $299 |
| Partner Commission (30%) | $90 |
| Rick's Net | $209 |
| Spots Available | 8 |
| Max Partner Payout | $720 (if all 8 book) |

**Tracking:** Use unique link or code (e.g., `?ref=partnername` or code `PARTNER30`)

---

## EMAIL OPTION 1: From Partner (Recommended)

**Best if your buddy sends from HIS email to HIS list — more trust.**

---

**Subject Lines (pick one):**
- My buddy coaches for the Orioles. He's taking 8 clients before spring training.
- The best hitting coach I know is available for 2 weeks
- $100 off — but only til Friday

---

**Email Body:**

Hey [First Name],

Quick one for you.

My buddy Rick Strickland just got hired as the AAA Hitting Coach for the Baltimore Orioles. He's the real deal — trained Pete Crow-Armstrong, Andrew Benintendi, Cedric Mullins, and Devin Williams (the St. Louis kid who won NL Rookie of the Year). Over 400 college commits.

Before he leaves for spring training, he's opening up **8 spots** for in-person assessments.

**What you get:**
- 2 hours with Rick, hands-on
- Full swing breakdown (video from every angle)
- Custom drill program for YOUR kid
- 30 days of text access to Rick after

**The price:**
~~$399~~ **$299** — but only til January 31.

[SEE WHAT THE ASSESSMENT INCLUDES →]

I've seen Rick work. He finds things other coaches miss. If your kid is serious about baseball, this is worth it.

He's got 8 spots. First come, first served.

— [Partner Name]

P.S. Here's a sample of the report you'll get:

[SCREENSHOT 1: Score page with big number]
[SCREENSHOT 2: Problem breakdown]
[SCREENSHOT 3: Drill prescription]

---

## EMAIL OPTION 2: From Rick (To Partner's List)

**If partner forwards or you send on their behalf.**

---

**Subject:** [Partner Name] said I should reach out

---

**Email Body:**

Hey [First Name],

[Partner Name] suggested I reach out to you.

I'm Rick Strickland — I just got hired as the AAA Hitting Coach for the Baltimore Orioles (Norfolk Tides). Before I report to spring training, I'm opening up 8 spots for in-person assessments.

**Here's the deal:**

2 hours with me. Full swing breakdown. Custom drill program. 30 days of text access after.

~~$399~~ **$299** til January 31.

[Partner Name] knows my work. I've trained Pete Crow-Armstrong, Andrew Benintendi, Cedric Mullins, and Devin Williams (St. Louis native, 2020 NL Rookie of the Year). Over 400 college commits and 78+ pro players.

I won't be available again until summer. This is your window.

[BOOK YOUR SPOT →]

— Rick Strickland
The Swing Rehab Coach
AAA Hitting Coach, Baltimore Orioles

P.S. Here's what the assessment report looks like:

[SCREENSHOT 1]
[SCREENSHOT 2]
[SCREENSHOT 3]

---

## SCREENSHOTS TO INCLUDE

### Screenshot 1: The Score Page
**What to show:** Big score circle (62), grade, player name
**Why:** Immediate visual impact — "I'll get a real score"

**Caption:** "Your overall swing score — see exactly where you stand"

---

### Screenshot 2: The Problem Breakdown
**What to show:** The weakest 4B category (BAT: 58) with the red bar
**Why:** Shows specificity — "He'll find MY problem"

**Caption:** "We identify your #1 problem — not 10 things, just the ONE that matters most"

---

### Screenshot 3: The Drill Prescription
**What to show:** Connection Ball drill box with sets/reps
**Why:** Shows they get actionable next steps

**Caption:** "Walk out with exactly what to do — sets, reps, and why it works"

---

### Screenshot 4 (Optional): The 30-Day Plan
**What to show:** Weekly schedule from Complete Review
**Why:** Shows ongoing value, not just one session

**Caption:** "Your custom 30-day plan to fix the problem"

---

## SCREENSHOT PLACEMENT IN EMAIL

```
[Email copy - first half]

[CTA BUTTON: Book Your Spot]

[Email copy - P.S. section]

"Here's what the report looks like:"

[Screenshot 1: Score] — "Your overall score"
[Screenshot 2: Problem] — "Your #1 problem identified"  
[Screenshot 3: Drill] — "Your fix, with exact sets and reps"

[CTA BUTTON: Book Your Spot — $299]
```

---

## PARTNER TRACKING OPTIONS

### Option 1: Unique Link
```
catchingbarrels.com/assessment?ref=partnername
```
You track clicks and conversions.

### Option 2: Discount Code
```
Use code PARTNERNAME at checkout
```
Partner's people get $299 price, you track by code usage.

### Option 3: Manual (Simplest)
Ask every booking: "How did you hear about this?"
If they say partner's name, pay commission.

---

## SIMPLE AFFILIATE AGREEMENT

**Partner:** [Buddy's Name]
**Promotion:** In-Person Assessment ($299)
**Commission:** 30% ($89.70, rounded to $90)
**Payment Terms:** Paid within 7 days of completed session
**Tracking:** [Code/Link/Manual]
**Duration:** January 2025 campaign only

**Terms:**
- Commission paid only on completed sessions (no refunds/no-shows)
- Partner may not misrepresent Rick's credentials or offer
- Rick provides all marketing copy and images
- Partner sends to their own list only

**Signatures:**

Rick Strickland: _________________ Date: _______

[Partner Name]: _________________ Date: _______

---

## FOLLOW-UP EMAIL (Send 3 Days Later)

**Subject:** 5 spots left (partner's list follow-up)

---

Hey [First Name],

Quick follow-up on Rick Strickland's in-person assessments.

5 spots left. $299 price ends January 31.

If you missed the first email, here's the deal:

- 2 hours with an AAA Hitting Coach (Baltimore Orioles)
- Full swing breakdown + custom drill program
- 30 days of text access to Rick

He's trained Pete Crow-Armstrong, Andrew Benintendi, and Devin Williams (the St. Louis kid). This is the real deal.

[BOOK YOUR SPOT →]

— [Partner Name]

---

## FINAL EMAIL (January 31)

**Subject:** Last day — $299 ends tonight

---

Today's the last day for the $299 price.

Tomorrow it's $399.

Rick leaves for Orioles spring training next week.

If you want in: [BOOK NOW →]

— [Partner Name]

---

## WHAT'S IN THE ZIP NOW

After this update, your deployment package includes:

1. `reportGenerator_v2.py` — PDF generator
2. `swingAggregation.ts` — Multi-swing logic
3. `REPLIT_DEPLOYMENT.md` — Setup guide
4. `VideoAnalyzer_MultiSwing_Upgrade_Spec.md` — Full UI spec
5. `RickStrickland_Bio_Story.md` — Bio for all platforms
6. `RickStrickland_Photo_Assets_Guide.md` — Photo placement guide
7. `CatchingBarrels_Product_Stack.md` — Full product ladder
8. **`Partner_Email_Campaign.md`** — This file (partner emails + affiliate terms)

---

**End of Partner Email Campaign**
