# Lovable Prompt: CATCHING BARRELS Full Marketing Site
## Complete Website Build

---

## BRAND UPDATE

**Change the accent color throughout the entire app:**

```css
/* OLD - Remove */
--accent: #F97316;  /* Orange */

/* NEW - Use this */
--accent: #DC2626;  /* Red - matches logo */
```

**Logo Lockup (CREATE THIS):**
- Icon: Brain with baseball bat (red) — user will upload
- Name: **CATCHING BARRELS** (bold, clean sans-serif like Inter)
- Tagline: "Unlock Your Swing DNA" (smaller, below the name)
- Color: Red (#DC2626)
- Use the red brain icon as favicon

**Logo Layout:**
```
[🧠🏏]  CATCHING BARRELS
        Unlock Your Swing DNA
```

**Update ALL instances of "BARRELS" to "CATCHING BARRELS" throughout the app.**

---

## SITE STRUCTURE

Build these pages:

```
/ (Homepage)
/analyze (Video Analyzer - already built)
/about (About Rick)
/inner-circle (Premium membership sales page)
/assessment (In-Person Assessment booking)
```

---

## PAGE 1: HOMEPAGE

### Route: `/`

### Hero Section

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  [CATCHING BARRELS LOGO]               Products  About  Inner Circle   [Login]  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│                                                                             │
│     UNLOCK YOUR SWING DNA                                                   │
│                                                                             │
│     Get your swing analyzed by an AAA Hitting Coach.                        │
│     Find your #1 problem. Get the drill to fix it.                          │
│                                                                             │
│                                                                             │
│     [GET YOUR SWING ANALYZED — $37]        [See How It Works ↓]             │
│                                                                             │
│                                                                             │
│     ─────────────────────────────────────────────────────────────────────   │
│                                                                             │
│     Trusted by players who made it to:                                      │
│                                                                             │
│     [Cubs Logo]  [Orioles Logo]  [Brewers Logo]  [Royals Logo]              │
│                                                                             │
│     Pete Crow-Armstrong • Andrew Benintendi • Cedric Mullins • Devin Williams
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Hero Background:** Dark (#0F172A) with subtle grid pattern or baseball field texture

---

### "How It Works" Section

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                         HOW IT WORKS                                        │
│                                                                             │
│     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐                │
│     │             │     │             │     │             │                │
│     │     📹      │     │     🧠      │     │     📋      │                │
│     │             │     │             │     │             │                │
│     │  1. UPLOAD  │     │ 2. ANALYZE  │     │  3. FIX     │                │
│     │             │     │             │     │             │                │
│     │ Record your │     │ We score    │     │ Get your    │                │
│     │ swing and   │     │ your Brain, │     │ personalized│                │
│     │ upload it   │     │ Body, Bat   │     │ drill plan  │                │
│     │             │     │ & Ball      │     │             │                │
│     └─────────────┘     └─────────────┘     └─────────────┘                │
│                                                                             │
│                     [GET STARTED — $37]                                     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### "The 4B System" Section

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                    THE 4B SYSTEM™                                           │
│           We analyze 4 components of your swing                             │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │                                                                       │ │
│  │   🧠 BRAIN        How you time and sequence your swing                │ │
│  │   ████████████████████████░░░░░░░░                                    │ │
│  │                                                                       │ │
│  │   💪 BODY         How you use your legs and hips                      │ │
│  │   ██████████████████████████░░░░░░                                    │ │
│  │                                                                       │ │
│  │   🏏 BAT          How you swing the bat                               │ │
│  │   ████████████████░░░░░░░░░░░░░░░░                    ← YOUR PROBLEM  │ │
│  │                                                                       │ │
│  │   ⚾ BALL         How hard you'll hit it                              │ │
│  │   ████████████████████████░░░░░░░░                                    │ │
│  │                                                                       │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│        Most coaches guess. We measure. Then we fix the weakest link.        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### "About Rick" Section (Homepage Preview)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   ┌─────────────┐                                                           │
│   │             │    MEET YOUR COACH                                        │
│   │   [RICK     │                                                           │
│   │   PHOTO]    │    Rick Strickland                                        │
│   │             │    The Swing Rehab Coach                                  │
│   │             │    AAA Hitting Coach, Baltimore Orioles                   │
│   └─────────────┘                                                           │
│                                                                             │
│   Rick doesn't guess. He diagnoses your swing like a doctor                 │
│   diagnoses an injury — find the problem, prescribe the fix,                │
│   track your progress.                                                      │
│                                                                             │
│   ✓ 400+ college commits                                                    │
│   ✓ 78+ professional players                                                │
│   ✓ 3 MLB Award Winners                                                     │
│   ✓ Technology Pioneer: HitTrax, Blast Motion, Rapsodo,                     │
│     Diamond Kinetics, Uplift, Reboot Motion                                 │
│                                                                             │
│                        [LEARN MORE ABOUT RICK →]                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Social Proof Section

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                 PLAYERS RICK HAS TRAINED                                    │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │  [BENINTENDI PHOTO]                                                 │  │
│   │                                                                     │  │
│   │  "Rick with Andrew Benintendi — Gold Glove Winner,                  │  │
│   │   World Series Champion"                                            │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐                  │
│   │ Pete      │ │ Cedric    │ │ Devin     │ │ Carson    │                  │
│   │ Crow-     │ │ Mullins   │ │ Williams  │ │ Kelly     │                  │
│   │ Armstrong │ │           │ │           │ │           │                  │
│   │           │ │ Orioles   │ │ NL ROY    │ │ All-Star  │                  │
│   │ Cubs      │ │           │ │ 2020      │ │           │                  │
│   └───────────┘ └───────────┘ └───────────┘ └───────────┘                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### Pricing Section

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                        CHOOSE YOUR ANALYSIS                                 │
│                                                                             │
│   ┌─────────────────────────┐     ┌─────────────────────────┐              │
│   │                         │     │    ⭐ MOST POPULAR       │              │
│   │   SINGLE SWING SCORE    │     │                         │              │
│   │                         │     │   COMPLETE REVIEW       │              │
│   │   $37                   │     │                         │              │
│   │                         │     │   $97                   │              │
│   │   • 1 swing analyzed    │     │                         │              │
│   │   • Your #1 problem     │     │   • 5 swings analyzed   │              │
│   │   • 1 drill to fix it   │     │   • Consistency score   │              │
│   │   • PDF report          │     │   • Age comparison      │              │
│   │                         │     │   • 30-day drill plan   │              │
│   │                         │     │   • PDF report          │              │
│   │   [GET STARTED]         │     │                         │              │
│   │                         │     │   [GET STARTED]         │              │
│   └─────────────────────────┘     └─────────────────────────┘              │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   Want personal coaching from Rick?                                         │
│   [JOIN RICK'S INNER CIRCLE — $297/month →]                                │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### FAQ Section

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                      FREQUENTLY ASKED QUESTIONS                             │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │ ▶ How do I record my swing?                                         │  │
│   ├─────────────────────────────────────────────────────────────────────┤  │
│   │ ▶ What equipment do I need?                                         │  │
│   ├─────────────────────────────────────────────────────────────────────┤  │
│   │ ▶ How long until I get my results?                                  │  │
│   ├─────────────────────────────────────────────────────────────────────┤  │
│   │ ▶ What's the difference between Single Swing and Complete Review?   │  │
│   ├─────────────────────────────────────────────────────────────────────┤  │
│   │ ▶ Who is Rick Strickland?                                           │  │
│   ├─────────────────────────────────────────────────────────────────────┤  │
│   │ ▶ Can I get a refund?                                               │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**FAQ Answers:**

**How do I record my swing?**
Side angle, 10-15 feet away, hip height, landscape mode. Full body visible. One swing per video.

**What equipment do I need?**
Just your phone. Any iPhone or Android from the last 5 years works. No sensors required.

**How long until I get my results?**
Usually 30-60 seconds. Your PDF report is emailed immediately.

**What's the difference between Single Swing and Complete Review?**
Single Swing analyzes 1 video and finds your #1 problem. Complete Review analyzes 5 swings, shows your consistency, compares you to your age group, and gives you a 30-day plan.

**Who is Rick Strickland?**
Rick is the AAA Hitting Coach for the Baltimore Orioles (Norfolk Tides). He's trained 400+ college commits, 78+ pro players, and 3 MLB Award Winners including Andrew Benintendi and Devin Williams.

**Can I get a refund?**
If you're not satisfied, email us within 24 hours of purchase and we'll refund you. No questions asked.

---

### Footer

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│   [CATCHING BARRELS LOGO]     Products        Contact                       │
│                               • Single Swing  • support@catchingbarrels.com │
│   Unlock Your Swing DNA       • Complete      • @catchingbarrels            │
│                               • Inner Circle                                │
│                               • In-Person                                   │
│                                                                             │
│   © 2025 Catching Barrels. All rights reserved.        Terms | Privacy      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## PAGE 2: ABOUT RICK

### Route: `/about`

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                        MEET RICK STRICKLAND                                 │
│                        The Swing Rehab Coach                                │
│                                                                             │
│   ┌───────────────────────────────────────────────────────────────────┐    │
│   │                                                                   │    │
│   │   [LARGE PHOTO - Rick with Benintendi or coaching action shot]    │    │
│   │                                                                   │    │
│   └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│   Rick Strickland is the AAA Hitting Coach for the Baltimore Orioles       │
│   (Norfolk Tides). He's trained 400+ college commits, 78+ professional     │
│   players, and 3 MLB Award Winners.                                        │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   THE SWING REHAB COACH                                                     │
│                                                                             │
│   Rick doesn't guess. He diagnoses swing problems like a doctor             │
│   diagnoses injuries:                                                       │
│                                                                             │
│   1. Find the exact problem (not just "swing harder")                       │
│   2. Prescribe the exact drill (not 50 random exercises)                    │
│   3. Track your progress (with the same tech MLB teams use)                 │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   TECHNOLOGY PIONEER                                                        │
│                                                                             │
│   Rick helped build the systems that power modern baseball:                 │
│                                                                             │
│   [HitTrax] [Blast Motion] [Rapsodo] [Diamond Kinetics] [Reboot Motion]    │
│                                                                             │
│   When Rick analyzes your swing, he's using technology he helped create.   │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   CREDENTIALS                                                               │
│                                                                             │
│   • AAA Hitting Coach, Baltimore Orioles (Norfolk Tides)                   │
│   • New York Yankees Draft Pick                                            │
│   • MLB Scout: New York Mets, Tampa Bay Rays                               │
│   • 30+ years in professional baseball                                      │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   PLAYERS RICK HAS TRAINED                                                  │
│                                                                             │
│   MLB Award Winners:                                                        │
│   • Andrew Benintendi — Gold Glove, World Series Champion                  │
│   • Jake Odorizzi — All-Star                                               │
│   • Devin Williams — 2020 NL Rookie of the Year                            │
│                                                                             │
│   Other MLB Players:                                                        │
│   Pete Crow-Armstrong • Cedric Mullins • Matt Adams • Carson Kelly         │
│   Chad Green • Matt Shaw • Moisés Ballesteros • Joe Boyle                  │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│                    [GET YOUR SWING ANALYZED →]                              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## PAGE 3: INNER CIRCLE SALES PAGE

### Route: `/inner-circle`

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│            WANT PERSONAL COACHING FROM AN AAA HITTING COACH?                │
│                                                                             │
│                     RICK'S INNER CIRCLE                                     │
│                                                                             │
│                        $297/month                                           │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   WHAT YOU GET:                                                             │
│                                                                             │
│   ✓ 2 Personal Video Reviews from Rick Every Month                         │
│     Send your swings. Rick records a personal breakdown video for you.     │
│                                                                             │
│   ✓ Weekly Group Coaching Calls                                            │
│     Live Q&A with Rick. Ask anything. Get real answers.                    │
│                                                                             │
│   ✓ Direct Access to Rick via Chat                                         │
│     Text Rick questions anytime. He responds within 24 hours.              │
│                                                                             │
│   ✓ Unlimited Swing Analysis                                               │
│     Upload as many swings as you want. Full 4B breakdown every time.       │
│                                                                             │
│   ✓ S2 Cognition Brain Testing (Add-On Available)                          │
│     The same brain test MLB teams use to evaluate players.                 │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   WHO IS THIS FOR?                                                          │
│                                                                             │
│   • Serious players who want to get recruited                              │
│   • Players preparing for showcases or tryouts                             │
│   • Parents who want their kid coached by the best                         │
│   • Anyone who wants ongoing access to an AAA hitting coach                │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   ┌───────────────────────────────────────────────────────────────────┐    │
│   │                                                                   │    │
│   │   "I use the same drills with my AAA players that I use with     │    │
│   │    Inner Circle members. The swing is the swing — it works       │    │
│   │    at every level."                                              │    │
│   │                                                                   │    │
│   │    — Rick Strickland, AAA Hitting Coach, Baltimore Orioles       │    │
│   │                                                                   │    │
│   └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│                        ⚠️ Only 12 spots available                          │
│                                                                             │
│                      [JOIN THE INNER CIRCLE →]                             │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   GUARANTEE                                                                 │
│                                                                             │
│   Add 5+ mph to your exit velocity in 90 days or get your money back.      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## PAGE 4: IN-PERSON ASSESSMENT

### Route: `/assessment`

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│         TRAIN WITH RICK BEFORE HE LEAVES FOR SPRING TRAINING                │
│                                                                             │
│                   2-HOUR IN-PERSON ASSESSMENT                               │
│                                                                             │
│                    ~~$399~~  $299                                           │
│                                                                             │
│               ⏰ Founders Pricing Ends January 31                           │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   Rick is reporting to Orioles spring training in February.                │
│   This is your last chance to train with him in person.                    │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   WHAT YOU GET:                                                             │
│                                                                             │
│   ✓ 90 Minutes of Hands-On Coaching                                        │
│     Rick will video your swing, identify what's wrong, and fix it          │
│     on the spot. You'll see improvement before you leave.                  │
│                                                                             │
│   ✓ Your Personal Drill Program                                            │
│     Walk out with a custom 30-day plan — the exact drills for YOUR         │
│     problems. Video demonstrations included.                               │
│                                                                             │
│   ✓ 30 Days of Text Access to Rick                                         │
│     Text Rick anytime for the next 30 days. Send swing videos.             │
│     Ask questions. Stay on track.                                          │
│                                                                             │
│   ✓ Your Written Report                                                    │
│     Full 4B breakdown with scores, priorities, and prescriptions.          │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   OPTIONAL ADD-ON:                                                          │
│                                                                             │
│   S2 Cognition Brain Test — +$150                                          │
│   The same test MLB teams use to evaluate players.                         │
│   See how your brain processes pitches.                                    │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│                      ⚠️ Only 8 spots available                             │
│                                                                             │
│                    [BOOK YOUR SPOT — $299 →]                               │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   LOCATION: [Your Facility Address]                                        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## NAVIGATION

```tsx
const navigation = [
  { name: 'Home', href: '/' },
  { name: 'Get Analyzed', href: '/analyze' },
  { name: 'About Rick', href: '/about' },
  { name: 'Inner Circle', href: '/inner-circle' },
  { name: 'In-Person', href: '/assessment' },
];
```

---

## COLOR SCHEME (UPDATED)

```css
:root {
  /* Primary */
  --primary: #0F172A;        /* Near-black (authority) */
  --accent: #DC2626;         /* RED - matches logo */
  
  /* Backgrounds */
  --white: #FFFFFF;
  --surface: #F8FAFC;        /* Light gray for cards */
  
  /* Status */
  --success: #22C55E;        /* Green */
  --warning: #F59E0B;        /* Amber */
  --danger: #DC2626;         /* Red (same as accent) */
  
  /* Text */
  --text-dark: #1E293B;      /* Primary text */
  --text-muted: #64748B;     /* Secondary text */
  
  /* Borders */
  --border: #E2E8F0;
}
```

---

## COMPONENT UPDATES

Update all buttons, highlights, and accents from orange to red:
- Primary buttons: Red background (#DC2626)
- Hover state: Darker red (#B91C1C)
- Score bars for "problem" category: Red
- Accent text: Red
- Links: Red on hover

---

## IMAGES NEEDED

| Location | Image |
|----------|-------|
| Hero background | Dark with subtle texture |
| About Rick - Main | Rick with Benintendi |
| About Rick - Secondary | Rick coaching in cage |
| Social proof | Player headshots or logos |
| Favicon | Red brain+bat icon from logo |

---

## END OF LOVABLE PROMPT
