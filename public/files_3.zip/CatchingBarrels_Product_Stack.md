# Catching Barrels - Complete Product Stack
## Updated January 2025

---

## THE VALUE LADDER

| Tier | Price | Target | Conversion Goal |
|------|-------|--------|-----------------|
| Single Swing Score™ | $37 | Cold traffic, curious parents | → Complete Review |
| Complete Swing Review™ | $97 | Serious players wanting full picture | → Elite Profile or In-Person |
| **In-Person Assessment** | ~~$399~~ **$299** (til Jan 31) | Local players, serious commitment | → Inner Circle |
| Elite Player Profile™ | $247 | Players wanting brain + body eval | → Inner Circle |
| Rick's Inner Circle | $297/mo | Committed players, ongoing coaching | Retention |

---

## IN-PERSON ASSESSMENT

### The Offer

**2-Hour In-Person Assessment with Rick Strickland**

~~$399~~ **$299** — Founders Pricing (Ends January 31)

### What You Get

✅ **Full Swing Evaluation** (90 minutes)
- Video analysis from multiple angles
- Live feedback and corrections
- Identify your #1, #2, #3 problems
- See improvement in real-time

✅ **Personalized Drill Program** 
- Custom drills for YOUR specific issues
- Video demonstrations you keep forever
- 30-day training plan to follow

✅ **30 Days of Text Access to Rick**
- Ask questions anytime
- Send swing videos for quick feedback
- Stay accountable while you train

✅ **Written Report**
- Your scores (Brain, Body, Bat, Ball)
- Priority issues ranked
- Drill prescription with sets/reps

### Optional Add-On

**S2 Cognition Brain Test** — +$150
- Same test MLB teams use to evaluate players
- Timing Control, Trajectory Prediction, Take Decisions
- See how your brain stacks up
- Cognitive training drills included

---

## BOOKING PAGE COPY

### Headline Options

**Option A (Scarcity + Authority):**
> Train with an AAA Hitting Coach — Before He's Gone

**Option B (Urgency + Discount):**
> $100 Off In-Person Assessments — Ends January 31

**Option C (Direct):**
> 2 Hours with Rick Strickland — $299 (Limited Time)

---

### Hero Section

# Train with Rick Strickland
## AAA Hitting Coach, Baltimore Orioles

**2-Hour In-Person Assessment**

~~$399~~ **$299** — Founders Pricing Ends January 31

Rick is reporting to Orioles spring training in February. This is your last chance to train with him in person before he's gone.

**Only 8 spots available.**

[BOOK YOUR SPOT →]

---

### What You Get

**90 Minutes of Hands-On Coaching**

Rick will video your swing from multiple angles, identify exactly what's holding you back, and fix it on the spot. You'll see improvement before you leave.

**Your Personal Drill Program**

Walk out with a custom 30-day plan — the exact drills to fix YOUR problems. Video demonstrations included.

**30 Days of Direct Access**

Text Rick anytime for the next 30 days. Send swing videos. Ask questions. Stay on track.

**Your Written Report**

Full breakdown of your swing with scores, priorities, and prescriptions. The same analysis Rick does for AAA players.

---

### Who Is Rick?

**Rick Strickland — The Swing Rehab Coach**

- AAA Hitting Coach, Baltimore Orioles (Norfolk Tides)
- Developed 400+ college commits, 78+ pro players
- Trained 3 MLB Award Winners (including Devin Williams, 2020 NL ROY)
- Worked with Andrew Benintendi, Cedric Mullins, Carson Kelly
- Technology Pioneer: HitTrax, Blast Motion, Rapsodo, Diamond Kinetics

**"I diagnose swing problems like a doctor diagnoses injuries. Find the problem, prescribe the fix, track the progress."**

[PHOTO: Rick with Benintendi]

---

### Why Now?

❌ Rick reports to Orioles spring training in February
❌ He won't be available for in-person sessions until summer
❌ Founders pricing ($100 off) ends January 31
❌ Only 8 spots left

**This is your window.**

[BOOK YOUR SPOT — $299 →]

---

### What Parents Are Saying

*[Placeholder for testimonials]*

> "Rick found the one thing that was killing my son's power. Fixed it in 20 minutes. Added 6 mph to his exit velo in two weeks."
> — Parent Name, City

> "Worth every penny. My daughter walked out with a clear plan and the confidence to execute it."
> — Parent Name, City

---

### The Process

**Step 1: Book Your Spot**
Pick a time that works. Pay $299 to reserve.

**Step 2: Show Up Ready**
Bring your bat, helmet, and gloves. Wear what you'd wear to practice.

**Step 3: Get Coached**
90 minutes of hands-on work with Rick. Video everything.

**Step 4: Walk Out With Your Plan**
Custom drills, written report, 30 days of text access.

---

### FAQ

**Where is the session?**
[Your facility address / partner facility]

**How long is the session?**
2 hours total — 90 minutes of coaching, 30 minutes for warmup/cooldown/discussion.

**What should I bring?**
Your bat, helmet, batting gloves. Wear athletic clothes.

**Can parents watch?**
Yes. We encourage it. You'll learn too.

**What if I need to reschedule?**
24-hour notice required. One reschedule allowed.

**Is the S2 Brain Test included?**
No, it's an optional add-on for $150. Highly recommended for serious players.

**When does the $299 price end?**
January 31, 2025. After that, it's $399.

---

### Book Now

**2-Hour In-Person Assessment**

~~$399~~ **$299**

Founders Pricing — Ends January 31

[BOOK YOUR SPOT →]

Only 8 spots available before Rick leaves for spring training.

---

## EMAIL SEQUENCE (3 Emails)

### Email 1: Announcement (Send Now)

**Subject:** Train with me before I leave for spring training

Hey [Name],

I'm reporting to Orioles spring training in a few weeks.

Before I go, I'm opening up 8 spots for in-person assessments at my facility.

**What you get:**
- 2 hours with me, hands-on
- Full swing breakdown (video + live feedback)
- Custom drill program to work on while I'm gone
- 30 days of text access to me

**The price:**
~~$399~~ $299 — founders pricing til January 31

This is the same evaluation I do with AAA players. Now you can get it.

[BOOK YOUR SPOT →]

I won't be available for in-person sessions again until summer. This is your window.

— Rick

P.S. Only 8 spots. First come, first served.

---

### Email 2: Reminder (3 days before deadline)

**Subject:** 4 spots left (and 3 days)

Quick update:

- 4 spots left for in-person assessments
- Founders pricing ($299) ends January 31
- I leave for spring training in February

If you've been thinking about it, now's the time.

[BOOK YOUR SPOT →]

— Rick

---

### Email 3: Last Call (January 31)

**Subject:** Last day for $299 assessments

Today's the last day for founders pricing.

Tomorrow it goes back to $399.

If you want 2 hours with me before I leave for Orioles spring training, book now:

[BOOK YOUR SPOT →]

— Rick

P.S. 2 spots left.

---

## SOCIAL MEDIA POSTS

### Post 1: Announcement

🚨 Last chance to train with me before spring training

I'm reporting to the Orioles in February. Before I go, I'm opening up 8 spots for in-person assessments.

2 hours. Full swing breakdown. Custom drill program. 30 days of text access.

~~$399~~ $299 til January 31.

Link in bio to book.

---

### Post 2: Countdown

3 days left for founders pricing.

$299 → $399 on February 1.

4 spots left.

[Link]

---

### Post 3: Last Day

Today only: $299 in-person assessments.

Tomorrow: $399.

I leave for spring training next week.

Last chance: [Link]

---

## UPDATED PRODUCT STACK SUMMARY

| Product | Price | S2 Included? | Best For |
|---------|-------|--------------|----------|
| Single Swing Score | $37 | No | Entry point, cold traffic |
| Complete Review | $97 | No | Remote players, full analysis |
| **In-Person Assessment** | **$299** (til Jan 31) / $399 | Optional +$150 | Local players, hands-on |
| Elite Player Profile | $247 | Yes | Brain + Body evaluation |
| Inner Circle | $297/mo | Unlimited | Ongoing coaching, serious players |

---

## THE FUNNEL FLOW

```
AWARENESS
├── YouTube / Social / Ads
└── "Train with an AAA coach"

ENTRY ($37)
├── Single Swing Score
└── Upsell → Complete Review

CORE ($97-$349)
├── Complete Review (remote)
├── In-Person Assessment (local)
└── Elite Player Profile (with S2)

PREMIUM ($297/mo)
├── Inner Circle
└── Unlimited everything + personal access
```

---

**End of Product Stack Document**
