# ChatGPT Analysis Prompt
## Comprehensive Report on Catching Barrels Conversations

---

**Copy everything below this line and paste into ChatGPT, then upload your conversation exports/transcripts:**

---

# PROMPT START

You are a business analyst and product strategist. I'm going to share transcripts/exports of my conversations about building a baseball swing analysis business called "Catching Barrels."

**Your job:** Read everything and produce a comprehensive report that captures:

---

## SECTION 1: BUSINESS OVERVIEW

Summarize the business:
- What is Catching Barrels?
- What problem does it solve?
- Who is the target customer?
- What is the core value proposition?

---

## SECTION 2: PRODUCT STACK

List every product/service mentioned with:
- Name
- Price point
- What's included
- Target customer for each tier
- Upsell path (what leads to what)

---

## SECTION 3: THE 4B SYSTEM

Explain my proprietary framework:
- What does each "B" stand for?
- What does each measure?
- How are they scored?
- How does it connect to S2 Cognition (brain testing)?
- How does it connect to Reboot Motion (biomechanics)?

---

## SECTION 4: RICK'S STORY & POSITIONING

Capture my personal brand:
- Professional background (teams, roles, playing career)
- Players I've trained (names, achievements)
- Technology partnerships (companies I've worked with)
- The "Swing Rehab Coach" positioning — what does it mean?
- Key credentials and proof points
- What makes me different from other hitting coaches?

---

## SECTION 5: HITTING PHILOSOPHY

Extract my beliefs about hitting:
- What do I believe about swing mechanics?
- What do I believe about training?
- What do I believe coaches get wrong?
- What frameworks or models do I use (motor profiles, anchor/engine/whip, etc.)?
- Any specific drills or methods I advocate for?
- Any specific things I'm against or think are overrated?

---

## SECTION 6: TECHNOLOGY PHILOSOPHY

How do I think about technology in baseball:
- Which tools/platforms do I use or recommend?
- How do I think about data vs. feel?
- How do I simplify complex data for players/parents?
- The "5th grade language" principle — explain it
- How do I balance tech with traditional coaching?

---

## SECTION 7: MARKETING & SALES APPROACH

Capture my marketing philosophy:
- Hormozi/Kennedy principles I've mentioned
- How I think about pricing
- How I think about scarcity/urgency
- How I think about upsells
- Partner/affiliate strategies mentioned
- Email marketing approaches
- Landing page strategies

---

## SECTION 8: FRUSTRATIONS & COMPLAINTS

What am I frustrated about?
- Things that annoy me about the industry
- Things I've complained about in building the business
- Technical problems or roadblocks
- People or approaches I disagree with
- What I wish was different

---

## SECTION 9: BRAIN DUMPS & RAW IDEAS

Capture any raw ideas, half-formed thoughts, or "what ifs" I mentioned:
- Features I want to build someday
- Markets I want to expand into
- Partnerships I'm considering
- Experiments I want to run
- Things I'm unsure about

---

## SECTION 10: KEY QUOTES

Pull out 10-20 of my most powerful or revealing quotes — things I said that capture my philosophy, personality, or approach. Format as:

> "Quote here"
> — Context: What we were discussing

---

## SECTION 11: TERMINOLOGY GLOSSARY

Create a glossary of terms I use:
- 4B System
- Brain, Body, Bat, Ball definitions
- Motor profiles (Spinner, Whipper, Slinger, etc.)
- KRS (if mentioned)
- Any other proprietary terms or jargon

---

## SECTION 12: ACTION ITEMS & NEXT STEPS

List any action items, to-dos, or next steps mentioned across the conversations:
- What I said I was going to do
- What was recommended to me
- Deadlines mentioned
- Priorities identified

---

## SECTION 13: RECOMMENDATIONS

Based on everything you've read, give me:

1. **3 things I should double down on** — What's working or has the most potential?

2. **3 blind spots or gaps** — What am I missing or not thinking about?

3. **3 quick wins** — What could I do in the next 7 days to move forward?

4. **1 big strategic recommendation** — If you could only tell me one thing, what would it be?

---

## OUTPUT FORMAT

- Use headers and subheaders for organization
- Use bullet points for lists
- Use tables where appropriate
- Include direct quotes where relevant
- Be specific — use names, numbers, and details from the conversations
- Total length: As long as needed to be comprehensive (aim for 3,000-5,000 words)

---

## CONTEXT ABOUT ME

Before you analyze, here's who I am:

**Name:** Rick Strickland
**Brand:** The Swing Rehab Coach
**Current Role:** AAA Hitting Coach, Baltimore Orioles (Norfolk Tides)
**Business:** Catching Barrels — swing analysis and coaching
**Location:** St. Louis area
**Experience:** 30+ years in baseball, trained 400+ college commits, 78+ pro players

---

# PROMPT END

---

**Now paste/upload your conversation transcripts below this prompt.**

---

## HOW TO EXPORT YOUR CONVERSATIONS

**From Claude:**
1. Click the "..." menu on a conversation
2. Click "Export" or copy/paste the full conversation

**From ChatGPT:**
1. Go to Settings → Data Controls → Export Data
2. Or copy/paste conversations manually

**From other tools:**
- Export as text, PDF, or markdown
- Copy/paste into a document

**Tip:** The more conversations you include, the better the analysis. Include:
- Product planning conversations
- Philosophy discussions
- Complaint sessions
- Brain dumps
- Technical build conversations

---

## ALTERNATIVE: FEED CONVERSATIONS ONE AT A TIME

If you have too much content for one prompt, use this approach:

**First message:**
"I'm going to share multiple conversation transcripts about my business Catching Barrels. After I share all of them, I'll ask you to analyze everything. Just say 'Got it' after each one until I say 'ANALYZE NOW.'"

**Then paste conversations one by one.**

**Final message:**
"ANALYZE NOW. Use the comprehensive report format I described."

---

**End of prompt document.**
