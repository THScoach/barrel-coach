# Rick Strickland — The Swing Rehab Coach
## Complete Bio & Story For All Platforms

---

## The One-Liner (For Headers)

```
Rick Strickland — The Swing Rehab Coach
AAA Hitting Coach, Baltimore Orioles (Norfolk Tides)
```

---

## The 50-Word Bio (For Report Footers)

Rick Strickland is the AAA Hitting Coach for the Baltimore Orioles (Norfolk Tides). Known as "The Swing Rehab Coach," he's developed 400+ college commits and 78+ professional players, including 3 MLB Award Winners. He helped build the technology that powers modern baseball analysis.

---

## The 100-Word Bio (For About Pages)

Rick Strickland is the AAA Hitting Coach for the Baltimore Orioles, where he works daily with professional players preparing for Major League Baseball.

Known as "The Swing Rehab Coach," Rick doesn't just coach — he diagnoses swing problems like a doctor, prescribes specific drills to fix them, and tracks progress until the swing is fixed.

Rick helped build the systems that power modern baseball technology, working with HitTrax, Blast Motion, Rapsodo, Diamond Kinetics, Uplift, and Reboot Motion.

His players: 400+ college commits, 78+ professional players, and 3 MLB Award Winners.

---

## The Full Story (For Landing Pages)

### The Swing Rehab Coach

Most hitting coaches watch video and guess.

Rick Strickland built the technology that eliminated guessing.

Over the past 15 years, Rick has worked with every major baseball technology company:

- **HitTrax** — The industry standard for hitting analysis
- **Blast Motion** — Bat sensor technology used by MLB teams
- **Rapsodo** — Pitch tracking and hitting metrics
- **Diamond Kinetics** — Swing analysis sensors
- **Uplift** — Performance training platforms
- **Reboot Motion** — Biomechanics analysis

He didn't just use these systems. He helped build them.

Now, Rick is the AAA Hitting Coach for the Baltimore Orioles (Norfolk Tides), where he works daily with professional players who are one step from the Major Leagues.

### The Results

- **400+ college commits**
- **78+ professional players**
- **3 MLB Award Winners:**
  - Andrew Benintendi (Gold Glove, World Series Champion)
  - Jake Odorizzi (All-Star)
  - Devin Williams (2020 NL Rookie of the Year)

### Other MLB Players Rick Has Coached

Cedric Mullins | Matt Adams | Carson Kelly | Chad Green | Matt Shaw | Moisés Ballesteros | Joe Boyle | Trevor Richards | Matt Reynolds | Jacob Brentz

### The Swing Rehab Philosophy

When a player gets injured, they don't just "try harder." They go to a specialist who:

1. **Diagnoses** the exact problem
2. **Prescribes** specific exercises
3. **Tracks progress** until they're healed

Your swing works the same way.

Most kids are losing 10-15 mph of power because of one or two fixable problems. But they don't know what's wrong, so they just "swing harder" and hope it gets better.

That's where Rick comes in.

Rick diagnoses your swing like a doctor diagnoses an injury:
- Find the exact problem (not just "swing harder")
- Prescribe the exact drill (not 50 random exercises)
- Track your progress (with the same technology MLB teams use)

That's Swing Rehab.

---

## Credentials Summary

### Current Role
- AAA Hitting Coach, Baltimore Orioles (Norfolk Tides)

### Playing Career
- New York Yankees Draft Pick
- Austin Peay Standout

### Scouting Experience
- MLB Scout: New York Mets
- MLB Scout: Tampa Bay Rays

### Technology Partnerships
- HitTrax
- Blast Motion
- Rapsodo
- Diamond Kinetics
- Uplift
- Reboot Motion

### Development Results
- 400+ college commits
- 78+ professional players
- 3 MLB Award Winners

### MLB Award Winners Developed
| Player | Award |
|--------|-------|
| Andrew Benintendi | Gold Glove, World Series Champion |
| Jake Odorizzi | All-Star |
| Devin Williams | 2020 NL Rookie of the Year |

### MLB Players Coached
- Pete Crow-Armstrong
- Andrew Benintendi
- Cedric Mullins
- Devin Williams
- Matt Adams
- Carson Kelly
- Chad Green
- Matt Shaw
- Moisés Ballesteros
- Joe Boyle
- Trevor Richards
- Matt Reynolds
- Jacob Brentz

### MLB Hitting Coaches Under Rick's Umbrella
- Matt Borsholti
- Cody Ashey

---

## Key Quotes (Use These in Marketing)

### On His Philosophy
> "I use the same drills with my AAA players that I use with 12-year-olds. The swing is the swing — it works at every level."

### On Technology
> "When I analyze your swing, I'm not guessing. I'm using systems I helped build for professional baseball — the same technology that costs MLB teams $50,000+ per year."

### On Swing Rehab
> "Most kids are losing 10-15 mph of power because of one or two fixable problems. My job is to find those problems and give you the exact drills to fix them — the same drills I use with professional players."

### On Results
> "If you're not getting better, you're not doing the right drills. It's that simple."

---

## The "Why Rick Is Different" Summary

### Most Hitting Coaches:
- Watch video and guess
- Give generic advice ("keep your hands back")
- Have no credentials beyond "I played college ball"

### Rick Strickland:
- Helped build the technology that powers modern baseball (HitTrax, Blast, Rapsodo, etc.)
- Currently coaches AAA players for the Baltimore Orioles
- Uses the same systems that cost MLB teams $50,000+ per year
- Has developed 400+ college commits and 78+ pro players
- Offers it to you for $37 (Single Swing) or $297/month (Inner Circle)

---

## Social Proof Statements

### For Parents
"If Rick is good enough for AAA players who are one step from the Major Leagues, he's definitely good enough for my kid."

### For Players
"The same coach who works with Cedric Mullins can analyze my swing? That's insane."

### For Skeptics
"Rick didn't just use HitTrax and Blast Motion — he helped BUILD them. That's a different level."

---

## Where to Use This Content

| Platform | Use |
|----------|-----|
| PDF Reports | Header (name + title + AAA) + Upsell pages (full story) |
| Video Analyzer | Footer or "Who analyzed" section |
| Landing Pages | Full story in hero section |
| Email Sequences | Subject lines + story fragments |
| Social Media | Quotes + credentials |
| Inner Circle Sales Page | Full story + results + testimonials |

---

## Image Requirements (Rick to Provide)

1. **Headshot** — Professional, in Orioles gear
2. **Action Shot** — Working with player in cage
3. **Stadium Shot** — At Harbor Park (Norfolk Tides home field)
4. **With MLB Player** — Any of the players listed above
5. **Technology Shot** — Working with HitTrax or similar equipment

---

**End of Bio Document**
