# Rick Strickland Photo Assets Guide
## For Landing Pages, PDFs, and Marketing Materials

---

## Quick Reference

| File Name | Description | Primary Use | Priority |
|-----------|-------------|-------------|----------|
| `benintendi.png` | Rick with Andrew Benintendi in batting cage | Hero sections, social proof | ⭐⭐⭐ HIGHEST |
| `avatar.png` | Illustrated portrait (circular) | Profile pics, headers | ⭐⭐⭐ |
| `tablet-analysis.png` | Hands holding tablet with swing video | Technology section | ⭐⭐⭐ |
| `hands-on-coaching.png` | Rick adjusting player's swing position | "How It Works" | ⭐⭐ |
| `mets-bp.png` | Rick in Mets gear throwing BP | MLB background | ⭐⭐ |
| `cage-coaching.png` | Rick coaching player in indoor cage | Testimonials section | ⭐⭐ |
| `youth-training.jpeg` | Rick with group of youth players | Parents landing page | ⭐⭐ |
| `cubs-dugout.jpeg` | Rick in Cubs uniform in dugout | "Rick's Journey" | ⭐⭐ |
| `throwing-bp.png` | Rick mid-throw demonstrating | Social media, blogs | ⭐ |

---

## Hero Section Photos

### PRIMARY: Benintendi Photo
**File:** `1767970615978_image.png`

![Benintendi](Use this as main hero)

**What it shows:** Rick standing with Andrew Benintendi in a professional batting cage facility.

**Why it's the best:** 
- Proves Rick trained an MLB Award Winner (Gold Glove, World Series Champion)
- Indoor cage setting looks professional
- Both are smiling, approachable
- Benintendi is recognizable to baseball families

**Caption options:**
- "Rick with Andrew Benintendi — Gold Glove winner and World Series Champion"
- "Rick has trained 3 MLB Award Winners, including Andrew Benintendi"
- "The same coaching that developed Andrew Benintendi is now available to your player"

**Placement:**
- Landing page hero (above the fold)
- Inner Circle sales page
- "Results" or "Social Proof" section
- Email headers

**Size recommendations:**
- Hero: 1200x800px minimum
- Thumbnail: 400x300px
- Mobile: 800x600px

---

### SECONDARY: Illustrated Avatar
**File:** `IMG_1370.png`

**What it shows:** Clean, professional illustrated portrait of Rick in a polo shirt, circular crop with dark background.

**Why it works:**
- Consistent branding across platforms
- Works at any size (scales well)
- Professional but approachable
- Doesn't require photo permissions

**Use for:**
- Website header/nav
- PDF report headers
- Social media profile pictures
- Favicon (cropped tight)
- Email signature
- App icon

**Size recommendations:**
- Full size: 800x800px
- Profile pic: 200x200px
- Favicon: 32x32px or 64x64px

---

## Technology Pioneer Section

### Tablet Video Analysis
**File:** `1767970662325_image.png`

**What it shows:** Close-up of hands holding a tablet displaying swing analysis video with data overlays.

**Why it works:**
- Reinforces "Technology Pioneer" positioning
- Shows data-driven approach
- Modern, professional look
- Doesn't show faces (versatile)

**Caption options:**
- "Rick uses the same technology he helped develop for MLB teams"
- "Data-driven swing analysis — not guesswork"
- "The same technology that costs MLB teams $50,000+/year"

**Placement:**
- "How It Works" section
- "Technology" or "Our Approach" section
- Feature callouts
- Blog posts about tech

**Pair with copy:**
> "Rick helped build the systems that power modern baseball — HitTrax, Blast Motion, Rapsodo, Diamond Kinetics, Uplift, and Reboot Motion. When he analyzes your swing, he's using technology he helped create."

---

## Coaching Action Shots

### Hands-On Swing Adjustment
**File:** `1767970597777_image.png`

**What it shows:** Rick physically adjusting a player's swing position/posture in a batting cage. Red design element in corner.

**Why it works:**
- Shows "The Swing Rehab Coach" in action
- Physical, hands-on coaching approach
- Professional facility setting
- Action shot (not posed)

**Caption options:**
- "Rick diagnosing a swing issue — just like a doctor diagnoses an injury"
- "Hands-on coaching from an AAA hitting coach"
- "The Swing Rehab Coach at work"

**Placement:**
- "How It Works" step 2 or 3
- "What You Get" section
- Testimonial backgrounds
- Blog headers

**Note:** Has red graphic element — may need cropping or can be used as-is for branded look.

---

### Indoor Cage Session
**File:** `1767970848502_image.png`

**What it shows:** Rick coaching a player mid-swing in indoor batting cage, demonstrating arm position.

**Why it works:**
- Shows active coaching moment
- Indoor facility = serious training
- Good angle showing both coach and player
- Natural, not posed

**Caption options:**
- "Real-time swing feedback"
- "Rick works with players at every level"
- "The same coaching AAA players get"

**Placement:**
- Testimonials section (background)
- "Training" section
- Mobile app screenshots mockup
- Video thumbnails

---

### Demonstrating Technique
**File:** `1767970878553_image.png`

**What it shows:** Rick mid-motion demonstrating throwing/movement, smiling, in facility with logo visible on shirt.

**Why it works:**
- Shows Rick is athletic, not just talking head
- Genuine smile = approachable
- Action shot
- Logo visible (branding)

**Placement:**
- "About Rick" section
- Social media posts
- Blog author photos
- Newsletter headers

---

## MLB Background Photos

### Mets BP Photo
**File:** `1767970646805_image.png`

**What it shows:** Rick in New York Mets gear (blue shirt, Mets cap) throwing batting practice on a professional field.

**Why it works:**
- Proves MLB scouting background (Mets scout)
- Professional field setting
- Action shot
- Recognizable MLB branding

**Caption options:**
- "Rick during his time as an MLB scout with the New York Mets"
- "From MLB scout to AAA Hitting Coach"
- "30+ years in professional baseball"

**Placement:**
- "Rick's Journey" timeline
- About page
- Credentials section
- Press/media kit

**Note:** Lower resolution — use at smaller sizes or as background with overlay.

---

### Cubs Dugout Photo
**File:** `103_0045.jpeg`

**What it shows:** Rick in Cubs uniform (#24 visible on teammate) in dugout/bullpen area, with small child watching game through fence.

**Why it works:**
- Shows actual MLB organization experience
- Authentic dugout setting
- Human element (child) connects with parents
- Candid, not staged

**Caption options:**
- "Rick in the dugout during his time with the Chicago Cubs organization"
- "From the Cubs organization to the Baltimore Orioles"
- "30+ years developing hitters at every level"

**Placement:**
- "Rick's Journey" section
- About page timeline
- Background image with text overlay

---

## Youth/Amateur Training

### Youth Group Training
**File:** `IMG_4826.jpeg`

**What it shows:** Coach (in yellow Lindenwood shirt) working with group of youth players (ages ~10-14) in indoor training facility with medicine balls and equipment visible.

**Why it works:**
- Shows Rick's system works with youth players
- Group setting = scalable
- Real facility with real equipment
- Diverse group of players

**Caption options:**
- "The same system that works with AAA players works with 12-year-olds"
- "Rick's methods have developed 400+ college commits"
- "Training the next generation"

**Placement:**
- Parents landing page
- "Who Is This For" section
- Youth programs page
- Testimonials from parents

**Note:** This appears to be a different coach/associate — verify before using as "Rick" photo. Could caption as "The Catching Barrels training system in action" instead.

---

## Photo Placement by Page

### Landing Page (catchingbarrels.com)

```
HERO SECTION
├── Background: Benintendi photo (dimmed 40%)
├── Overlay: Avatar (small, top left)
└── Badge: "As seen training MLB players"

HOW IT WORKS
├── Step 1: Tablet analysis photo
├── Step 2: Hands-on coaching photo
└── Step 3: Results/testimonial

SOCIAL PROOF
├── Main: Benintendi photo (full color)
├── Quote: "400+ college commits, 78+ pros, 3 MLB Award Winners"
└── Logos: Cubs, Mets, Orioles (if permitted)

ABOUT RICK
├── Avatar (large)
├── Timeline: Mets BP → Cubs dugout → Current
└── Credentials list
```

### Inner Circle Sales Page

```
HERO
├── Benintendi photo (hero)
└── Headline: "Get Coached by an AAA Hitting Coach"

WHAT YOU GET
├── Video review: Tablet analysis photo
├── Coaching calls: Cage coaching photo
└── Direct access: Avatar

PROOF
├── Benintendi photo
├── Stats: "400+ commits, 78+ pros"
└── Testimonials
```

### PDF Reports

```
HEADER (every page)
├── Avatar (small, 50x50px)
└── Name + Title + Credentials

UPSELL PAGE
├── Benintendi photo (if space)
├── Or: Avatar + credentials
└── Quote from Rick
```

---

## Image Specifications

### Web Optimization

| Use Case | Format | Max Size | Dimensions |
|----------|--------|----------|------------|
| Hero background | WebP/JPG | 200KB | 1920x1080 |
| Section photos | WebP/JPG | 100KB | 800x600 |
| Thumbnails | WebP/JPG | 30KB | 400x300 |
| Avatar/icons | PNG | 50KB | 200x200 |
| Mobile hero | WebP/JPG | 100KB | 800x600 |

### Print (PDFs)

| Use Case | Format | Resolution | 
|----------|--------|------------|
| Full page | JPG/PNG | 300 DPI |
| Half page | JPG/PNG | 300 DPI |
| Header icon | PNG | 150 DPI |

---

## Alt Text for Accessibility

| Photo | Alt Text |
|-------|----------|
| Benintendi | "Rick Strickland with MLB player Andrew Benintendi in batting cage" |
| Avatar | "Rick Strickland, The Swing Rehab Coach" |
| Tablet | "Swing analysis on tablet showing video breakdown" |
| Hands-on | "Rick Strickland adjusting a player's swing mechanics" |
| Mets BP | "Rick Strickland throwing batting practice as MLB scout" |
| Cubs dugout | "Rick Strickland in dugout during Cubs organization tenure" |
| Youth training | "Youth baseball players training at Catching Barrels facility" |
| Cage coaching | "Rick Strickland coaching player swing in batting cage" |

---

## Photos Still Needed

Once Rick gets to Orioles spring training:

1. **In Orioles gear on field** — Updates "current role" credibility
2. **Working with AAA player** — Shows current high-level coaching
3. **Harbor Park stadium shot** — Norfolk Tides home field
4. **With HitTrax/tech equipment** — Reinforces tech pioneer story
5. **Headshot in Orioles polo** — Updated professional photo

---

## Legal Notes

- **Benintendi photo:** Verify you have permission to use commercially. If taken during professional relationship, likely fine. If unsure, use with caption crediting the relationship rather than implying endorsement.
- **MLB logos:** Do NOT use Cubs/Mets/Orioles logos without permission. Mention organizations in text only.
- **Youth photos:** If using youth training photo, ensure parental consent was obtained for commercial use.

---

## File Naming Convention

Rename files for organization:

```
rick-strickland-avatar.png
rick-strickland-benintendi.png
rick-strickland-tablet-analysis.png
rick-strickland-coaching-cage.png
rick-strickland-mets-scout.png
rick-strickland-cubs-dugout.jpg
rick-strickland-youth-training.jpg
rick-strickland-hands-on.png
rick-strickland-demonstrating.png
```

---

**End of Photo Assets Guide**
